INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("6","2018-01-31","8","0",NULL,NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("14","2018-01-31","8","0",NULL,NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-09-01","8","0",NULL,NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("6","2018-01-02","8","0",NULL,"4");

