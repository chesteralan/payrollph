INSERT INTO payroll_employees_benefits (`id`,`payroll_id`,`name_id`,`benefit_id`,`entry_id`,`employee_share`,`employer_share`,`notes`,`manual`,`pe_id`)  VALUES("1","1","14","2","7","100.00000","100.00000",NULL,"0","7");

