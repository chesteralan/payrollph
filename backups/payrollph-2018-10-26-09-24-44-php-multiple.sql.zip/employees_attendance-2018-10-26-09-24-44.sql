INSERT INTO employees_attendance (`name_id`,`date_present`,`hours`,`notes`,`pe_id`)  VALUES("1","2018-01-01","8",NULL,NULL);

