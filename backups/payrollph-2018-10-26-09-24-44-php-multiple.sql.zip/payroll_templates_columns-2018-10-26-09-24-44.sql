INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","working_days");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","absences");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","rate_per_day");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","basic_salary");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","cola");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","absences_amount");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","net_pay");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","leave_benefits");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","gross_pay");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","earning_1");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","earning_2");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","benefit_1");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","benefit_2");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","benefit_3");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","deduction_1");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","deduction_2");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","deduction_3");

