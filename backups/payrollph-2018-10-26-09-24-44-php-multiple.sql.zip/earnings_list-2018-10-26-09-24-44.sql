INSERT INTO earnings_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("1","Honorarium","Honorarium",NULL,"1","0","HON");
INSERT INTO earnings_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("2","Allowance","Allowance",NULL,"1","0","ALW");

