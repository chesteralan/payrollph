INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("1","Salary Loan","Salary Loan",NULL,"1","0",NULL);
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("2","Cash Advance","Cash Advance",NULL,"1","0","CA");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("3","Adjustments","Adjustments",NULL,"1","0","ADJ");

