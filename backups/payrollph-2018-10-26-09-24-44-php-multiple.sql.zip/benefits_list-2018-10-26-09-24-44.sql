INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`,`abbr`)  VALUES("1","SSS","SSS","0",NULL,NULL,"1","0","SSS");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`,`abbr`)  VALUES("2","PHIC","PHIC","0",NULL,NULL,"1","0","PHIC");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`,`abbr`)  VALUES("3","HDMF","HDMF","0",NULL,NULL,"1","0","HDMF");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`,`abbr`)  VALUES("4","Sick or Vacation Leave","Sick or Vacation Leave","1",NULL,NULL,"1","0",NULL);

