INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("1","1","2","1","2","5000.00000","5,000.00 X 1 Month","0","1");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("2","1","3","1","8","5000.00000","5,000.00 X 1 Month","0","2");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("3","1","4","1","1","5000.00000","5,000.00 X 1 Month","0","3");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("4","1","13","2","7","750.00000","750.00 X 1 Month","0","10");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("5","1","9","2","3","1250.00000","1,250.00 X 1 Month","0","11");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("6","1","11","2","5","750.00000","750.00 X 1 Month","0","12");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("7","1","12","2","6","750.00000","750.00 X 1 Month","0","13");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("8","1","10","2","4","750.00000","750.00 X 1 Month","0","14");

