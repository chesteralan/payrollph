INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("1","alchie","941533a479a78dd89e3dacb0b38641809ed5bfcd","Alchie Tagudin");
INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("2","jess","56078d4284a2cbd3a49615a6f00a4ad6e05dbb68","Ariane Jess Loremas");
INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("3","fred","87288a5b100dc110adb07d9143cdaa7cf5b6c035","Siegfred Alegro");

