INSERT INTO account_sessions (`id`,`ip_address`,`timestamp`,`data`)  VALUES("81e23184ddec76c240c4d7dec1240188a88c2505","::1","1549675945","__ci_last_regenerate|i:1549675874;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:6:{s:6:\"system\";a:5:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"database\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"audit\";a:4:{s:4:\"view\";s:1:\"0\";s:3:\"add\";s:1:\"0\";s:4:\"edit\";s:1:\"0\";s:6:\"delete\";s:1:\"0\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:15:\"developer_tools\";a:1:{s:6:\"themes\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"reports\";a:1:{s:7:\"13month\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:6:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:9:\"companies\";i:2;s:5:\"terms\";i:3;s:8:\"database\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}s:15:\"developer_tools\";a:1:{i:0;s:6:\"themes\";}s:7:\"reports\";a:1:{i:0;s:7:\"13month\";}}user_settings|a:1:{s:5:\"theme\";s:15:\"_company_theme_\";}current_company|s:31:\"Archdiocesan Nourishment Center\";current_company_id|s:1:\"1\";current_company_theme|s:4:\"yeti\";referrer_uri|s:39:\"payroll_employees/dtr_settings/1/9/ajax\";current_payroll|O:8:\"stdClass\":12:{s:2:\"id\";s:1:\"1\";s:10:\"company_id\";s:1:\"1\";s:4:\"name\";s:18:\"January 1-15, 2018\";s:11:\"template_id\";s:1:\"1\";s:5:\"month\";s:1:\"1\";s:4:\"year\";s:4:\"2018\";s:6:\"active\";s:1:\"1\";s:4:\"lock\";s:1:\"0\";s:12:\"print_format\";s:0:\"\";s:8:\"group_by\";s:8:\"position\";s:10:\"checked_by\";s:1:\"1\";s:11:\"approved_by\";s:1:\"1\";}page_session|s:17:\"payroll_employees\";");
INSERT INTO account_sessions (`id`,`ip_address`,`timestamp`,`data`)  VALUES("8d2d79d89fc8eea273e99795db3d8f23c97c53bb","::1","1549676613","__ci_last_regenerate|i:1549676613;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:6:{s:6:\"system\";a:5:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"database\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"audit\";a:4:{s:4:\"view\";s:1:\"0\";s:3:\"add\";s:1:\"0\";s:4:\"edit\";s:1:\"0\";s:6:\"delete\";s:1:\"0\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:15:\"developer_tools\";a:1:{s:6:\"themes\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"reports\";a:1:{s:7:\"13month\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:6:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:9:\"companies\";i:2;s:5:\"terms\";i:3;s:8:\"database\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}s:15:\"developer_tools\";a:1:{i:0;s:6:\"themes\";}s:7:\"reports\";a:1:{i:0;s:7:\"13month\";}}user_settings|a:1:{s:5:\"theme\";s:15:\"_company_theme_\";}current_company|s:31:\"Archdiocesan Nourishment Center\";current_company_id|s:1:\"1\";current_company_theme|s:4:\"yeti\";referrer_uri|s:20:\"payroll_dtr/view/1/0\";current_payroll|O:8:\"stdClass\":12:{s:2:\"id\";s:1:\"1\";s:10:\"company_id\";s:1:\"1\";s:4:\"name\";s:18:\"January 1-15, 2018\";s:11:\"template_id\";s:1:\"1\";s:5:\"month\";s:1:\"1\";s:4:\"year\";s:4:\"2018\";s:6:\"active\";s:1:\"1\";s:4:\"lock\";s:1:\"0\";s:12:\"print_format\";s:0:\"\";s:8:\"group_by\";s:8:\"position\";s:10:\"checked_by\";s:1:\"1\";s:11:\"approved_by\";s:1:\"1\";}page_session|s:11:\"payroll_dtr\";");
INSERT INTO account_sessions (`id`,`ip_address`,`timestamp`,`data`)  VALUES("a4f1c216227b80fbc309eba403cdb317e55912a5","::1","1549675861","__ci_last_regenerate|i:1549675573;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:6:{s:6:\"system\";a:5:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"database\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"audit\";a:4:{s:4:\"view\";s:1:\"0\";s:3:\"add\";s:1:\"0\";s:4:\"edit\";s:1:\"0\";s:6:\"delete\";s:1:\"0\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:15:\"developer_tools\";a:1:{s:6:\"themes\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"reports\";a:1:{s:7:\"13month\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:6:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:9:\"companies\";i:2;s:5:\"terms\";i:3;s:8:\"database\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}s:15:\"developer_tools\";a:1:{i:0;s:6:\"themes\";}s:7:\"reports\";a:1:{i:0;s:7:\"13month\";}}user_settings|a:1:{s:5:\"theme\";s:15:\"_company_theme_\";}current_company|s:31:\"Archdiocesan Nourishment Center\";current_company_id|s:1:\"1\";current_company_theme|s:4:\"yeti\";referrer_uri|s:30:\"payroll/inclusive_dates/1/ajax\";current_payroll|O:8:\"stdClass\":12:{s:2:\"id\";s:1:\"1\";s:10:\"company_id\";s:1:\"1\";s:4:\"name\";s:18:\"January 1-15, 2018\";s:11:\"template_id\";s:1:\"1\";s:5:\"month\";s:1:\"1\";s:4:\"year\";s:4:\"2018\";s:6:\"active\";s:1:\"1\";s:4:\"lock\";s:1:\"0\";s:12:\"print_format\";s:0:\"\";s:8:\"group_by\";s:8:\"position\";s:10:\"checked_by\";s:1:\"1\";s:11:\"approved_by\";s:1:\"1\";}page_session|s:11:\"payroll_dtr\";");
INSERT INTO account_sessions (`id`,`ip_address`,`timestamp`,`data`)  VALUES("e21f4081176ad3421bccad3a430e24a6b83e26f4","::1","1550221696","__ci_last_regenerate|i:1550221687;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:6:{s:6:\"system\";a:5:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"database\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"audit\";a:4:{s:4:\"view\";s:1:\"0\";s:3:\"add\";s:1:\"0\";s:4:\"edit\";s:1:\"0\";s:6:\"delete\";s:1:\"0\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:15:\"developer_tools\";a:1:{s:6:\"themes\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"reports\";a:1:{s:7:\"13month\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:6:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:9:\"companies\";i:2;s:5:\"terms\";i:3;s:8:\"database\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}s:15:\"developer_tools\";a:1:{i:0;s:6:\"themes\";}s:7:\"reports\";a:1:{i:0;s:7:\"13month\";}}user_settings|a:1:{s:5:\"theme\";s:15:\"_company_theme_\";}current_company|s:31:\"Archdiocesan Nourishment Center\";current_company_id|s:1:\"1\";current_company_theme|s:4:\"yeti\";referrer_uri|s:15:\"system_database\";");

INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`,`abbr`)  VALUES("1","SSS","SSS","0",NULL,NULL,"1","0","SSS");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`,`abbr`)  VALUES("2","PHIC","PHIC","0",NULL,NULL,"1","0","PHIC");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`,`abbr`)  VALUES("3","HDMF","HDMF","0",NULL,NULL,"1","0","HDMF");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`,`abbr`)  VALUES("4","Sick or Vacation Leave","Sick or Vacation Leave","1",NULL,NULL,"1","0",NULL);


INSERT INTO companies_list (`id`,`theme`,`name`,`address`,`phone`,`notes`,`default`,`trash`)  VALUES("1","yeti","Archdiocesan Nourishment Center","Pag-asa St, Fatima, Davao City","082-285-1524",NULL,"1","0");

INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_employees","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_dtr","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_salaries","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_earnings","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_benefits","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_deductions","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_summary","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_sort","a:7:{i:0;s:22:\"column_group_employees\";i:1;s:16:\"column_group_dtr\";i:2;s:21:\"column_group_salaries\";i:3;s:21:\"column_group_earnings\";i:4;s:21:\"column_group_benefits\";i:5;s:23:\"column_group_deductions\";i:6;s:20:\"column_group_summary\";}");

INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("1","Salary Loan","Salary Loan",NULL,"1","0",NULL);
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("2","Cash Advance","Cash Advance",NULL,"1","0","CA");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("3","Adjustments","Adjustments",NULL,"1","0","ADJ");

INSERT INTO earnings_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("1","Honorarium","Honorarium",NULL,"1","0","HON");
INSERT INTO earnings_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`,`abbr`)  VALUES("2","Allowance","Allowance",NULL,"1","0","ALW");

INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("1","1","4","2","1","2018-09-18","1",NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("8","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("3","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("6","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("12","1","5","0","0","2019-01-07","0",NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("14","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("7","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("13","1","5","0","0","2019-01-07","0",NULL,"0",NULL);

INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("6","2018-01-31","8","0",NULL,NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("14","2018-01-31","8","0",NULL,NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-09-01","8","0",NULL,NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("6","2018-01-02","8","0",NULL,"4");
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-01-14","8","4",NULL,"9");
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-01-05","8",NULL,NULL,"9");
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-01-15","8","0",NULL,"9");
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-01-01","8",NULL,NULL,"9");
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-01-02","8",NULL,NULL,"9");
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-01-03","8",NULL,NULL,"9");
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-01-04","8",NULL,NULL,"9");
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`,`pe_id`)  VALUES("1","2018-01-06","8",NULL,NULL,"9");

INSERT INTO employees_areas (`id`,`company_id`,`trash`,`notes`,`name`)  VALUES("1","1","0",NULL,"Fatima");
INSERT INTO employees_areas (`id`,`company_id`,`trash`,`notes`,`name`)  VALUES("2","1","0",NULL,"Bucana");

INSERT INTO employees_attendance (`name_id`,`date_present`,`hours`,`notes`,`pe_id`)  VALUES("1","2018-01-01","8",NULL,NULL);

INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("1","1","6","1","165.00000","165.00000","2018-01-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("2","1","14","1","165.00000","165.00000","2018-01-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("3","1","3","1","165.00000","165.00000","2018-01-07","1","1",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("4","1","8","1","165.00000","165.00000","2018-01-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("5","1","7","1","165.00000","165.00000","2018-01-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("6","1","6","2","100.00000","100.00000","2018-02-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("7","1","14","2","100.00000","100.00000","1970-01-01","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("8","1","7","2","100.00000","100.00000","2018-02-07","1","0",NULL);

INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("1","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("2","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("3","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("4","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("5","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("6","1");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("7","1");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("8","1");


INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("1","1","14","1","500.00000","5000.00000","2018-01-07","month","1","0",NULL);
INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("2","1","6","1","1500.00000","15000.00000","2018-01-07","month","1","0",NULL);
INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("3","1","8","1","2000.00000","10000.00000","2018-02-07","month","1","0",NULL);
INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("4","1","13","1","500.00000","4000.00000","2018-01-01","month","1","0",NULL);
INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("5","1","14","1","500.00000","15000.00000","2018-01-24","month","1","0",NULL);

INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("1","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("1","2");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("2","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("2","2");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("3","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("3","2");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("4","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("4","2");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("5","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("5","2");

INSERT INTO employees_earnings (`id`,`company_id`,`name_id`,`earning_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`,`multiplier`)  VALUES("1","1","4","1","5000.00000","0.00000","2018-01-07","month","1","0",NULL,NULL);
INSERT INTO employees_earnings (`id`,`company_id`,`name_id`,`earning_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`,`multiplier`)  VALUES("2","1","2","1","5000.00000","0.00000","2018-01-07","month","1","0",NULL,NULL);
INSERT INTO employees_earnings (`id`,`company_id`,`name_id`,`earning_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`,`multiplier`)  VALUES("3","1","9","2","1250.00000","0.00000","2018-01-07","month","1","0",NULL,NULL);
INSERT INTO employees_earnings (`id`,`company_id`,`name_id`,`earning_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`,`multiplier`)  VALUES("4","1","10","2","750.00000","0.00000","2018-01-07","month","1","0",NULL,NULL);
INSERT INTO employees_earnings (`id`,`company_id`,`name_id`,`earning_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`,`multiplier`)  VALUES("5","1","11","2","750.00000","0.00000","2018-01-07","month","1","0",NULL,NULL);
INSERT INTO employees_earnings (`id`,`company_id`,`name_id`,`earning_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`,`multiplier`)  VALUES("6","1","12","2","750.00000","0.00000","2018-01-07","month","1","0",NULL,NULL);
INSERT INTO employees_earnings (`id`,`company_id`,`name_id`,`earning_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`,`multiplier`)  VALUES("7","1","13","2","750.00000","0.00000","2018-01-07","month","1","0",NULL,NULL);
INSERT INTO employees_earnings (`id`,`company_id`,`name_id`,`earning_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`,`multiplier`)  VALUES("8","1","3","1","5000.00000","0.00000","2018-01-07","month","1","0",NULL,NULL);

INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("1","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("1","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("2","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("2","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("3","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("3","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("4","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("4","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("5","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("5","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("6","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("6","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("7","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("7","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("8","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("8","2");

INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("1","0","Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("2","0","Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("3","0","Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("4","1","Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("5","1","Working Students",NULL,"0");

INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("1","1","7","4","15","2018");
INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("2","1","14","4","15","2018");
INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("3","1","6","4","15","2018");
INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("4","1","1","4","15","2018");
INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("5","1","8","4","15","2018");

INSERT INTO employees_positions (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("1","1","Cook",NULL,"0");
INSERT INTO employees_positions (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("2","1","Finance",NULL,"0");
INSERT INTO employees_positions (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("3","1","Admin",NULL,"0");
INSERT INTO employees_positions (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("4","1","Working Student","Working Student","0");

INSERT INTO employees_salaries (`id`,`company_id`,`name_id`,`amount`,`rate_per`,`days`,`annual_days`,`months`,`hours`,`cola`,`notes`,`manner`,`primary`,`trash`)  VALUES("1","1","6","10000.00000","month","26","312","12","8","0.00000",NULL,"semi-monthly","1","0");
INSERT INTO employees_salaries (`id`,`company_id`,`name_id`,`amount`,`rate_per`,`days`,`annual_days`,`months`,`hours`,`cola`,`notes`,`manner`,`primary`,`trash`)  VALUES("2","1","14","10000.00000","month","26","312","12","8","0.00000",NULL,"semi-monthly","1","0");
INSERT INTO employees_salaries (`id`,`company_id`,`name_id`,`amount`,`rate_per`,`days`,`annual_days`,`months`,`hours`,`cola`,`notes`,`manner`,`primary`,`trash`)  VALUES("3","1","7","8450.00000","month","26","312","12","8","0.00000",NULL,"daily","1","0");
INSERT INTO employees_salaries (`id`,`company_id`,`name_id`,`amount`,`rate_per`,`days`,`annual_days`,`months`,`hours`,`cola`,`notes`,`manner`,`primary`,`trash`)  VALUES("4","1","8","8450.00000","month","26","312","12","8","0.00000",NULL,"daily","1","0");
INSERT INTO employees_salaries (`id`,`company_id`,`name_id`,`amount`,`rate_per`,`days`,`annual_days`,`months`,`hours`,`cola`,`notes`,`manner`,`primary`,`trash`)  VALUES("5","1","1","5000.00000","month","26","312","12","8","0.00000",NULL,"daily","1","0");

INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("1","Tagudin","Chester Alan","B","1985-04-17",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("13","Galacio","Jemmar",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("12","Aclo","Jophord",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("7","Monesit","Mark Anthony",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("8","Tanudra","Narcisa",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("9","Mula","Winston",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("10","Capuno","PJ",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("11","#","Reniboy",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("6","Romero","Teddy",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("5","#","Essa",NULL,"1970-01-01",NULL,"male","single","Sr.","LGC");
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("4","Dailisan","Edna",NULL,"1970-01-01",NULL,"male","single","Sr.","LGC");
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("3","Tabucal","Melodia",NULL,"1970-01-01",NULL,"male","single","Sr.","LGC");
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("2","Inting","Ma. Felina",NULL,"1970-01-01",NULL,"female","single","Sr. ","LGC");
INSERT INTO names_info (`name_id`,`lastname`,`firstname`,`middlename`,`birthday`,`birthplace`,`gender`,`civil_status`,`prefix`,`suffix`)  VALUES("14","Potal","Chester Jake",NULL,"1970-01-01",NULL,"male","single",NULL,NULL);

INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("1","Chester Alan Tagudin","Mintal","+639462559955","0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("2","Sr. Ma. Felina Inting, LGC",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("3","Sr. Melodia Tabucal, LGC",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("4","Sr. Edna Dailisan, LGC",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("5","Sr. Essa",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("6","Teddy Romero",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("7","Mark Anthony Monesit",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("8","Narcisa Tanudra",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("9","Winston Mula",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("10","PJ Capuno",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("11","Reneboy",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("12","Jophord Aclo",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("13","Jemmar Galacio",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("14","Chester Jake Potal",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("15","shit",NULL,NULL,"0");

INSERT INTO names_meta (`meta_id`,`name_id`,`meta_key`,`meta_value`)  VALUES("1","1","sgl_number","123-456-789");
INSERT INTO names_meta (`meta_id`,`name_id`,`meta_key`,`meta_value`)  VALUES("2","1","sgl_expiry","09/14/2018");
INSERT INTO names_meta (`meta_id`,`name_id`,`meta_key`,`meta_value`)  VALUES("3","1","sgl_status","expired");

INSERT INTO payroll (`id`,`company_id`,`name`,`template_id`,`month`,`year`,`active`,`lock`,`print_format`,`group_by`,`checked_by`,`approved_by`)  VALUES("1","1","January 1-15, 2018","1","1","2018","1","0",NULL,"position","1","1");

INSERT INTO payroll_benefits (`payroll_id`,`benefit_id`,`order`)  VALUES("1","1","3");
INSERT INTO payroll_benefits (`payroll_id`,`benefit_id`,`order`)  VALUES("1","2","2");
INSERT INTO payroll_benefits (`payroll_id`,`benefit_id`,`order`)  VALUES("1","3","1");

INSERT INTO payroll_deductions (`payroll_id`,`deduction_id`,`order`)  VALUES("1","1","2");
INSERT INTO payroll_deductions (`payroll_id`,`deduction_id`,`order`)  VALUES("1","2","1");

INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("1","1","2");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("1","2","1");

INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("1","1","2","2","payslip","payslip",NULL,"1","1","4","3","1","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("2","1","3","6","payslip","payslip",NULL,"1",NULL,"4","0","0","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("3","1","4","1","payslip","payslip",NULL,"1","1","4","3","2","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("4","1","6","5","payslip","payslip",NULL,"1",NULL,"4","0","0","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("5","1","7","3","payslip","payslip",NULL,"1","1","4","1","2","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("6","1","8","8","payslip","payslip",NULL,"1",NULL,"4","0","0","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("7","1","14","4","payslip","payslip",NULL,"1",NULL,"4","0","0","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("8","1","5","0","payslip","payslip",NULL,"1","1","4","3","1","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("9","1","1","7","payslip","payslip",NULL,"1","1","4","2","1","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("10","1","13","3","payslip","payslip",NULL,"1",NULL,"5","0","1","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("11","1","9","0","payslip","none",NULL,"1",NULL,"5","0","0","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("12","1","11","0","payslip","payslip",NULL,"1","2","5","0","0","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("13","1","12","1","payslip","payslip",NULL,"1","3","5","4","1","0","0");
INSERT INTO payroll_employees (`id`,`payroll_id`,`name_id`,`order`,`payslip`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`,`manual`,`presence`)  VALUES("14","1","10","2","payslip","payslip",NULL,"1",NULL,"5","0","0","0","0");

INSERT INTO payroll_employees_benefits (`id`,`payroll_id`,`name_id`,`benefit_id`,`entry_id`,`employee_share`,`employer_share`,`notes`,`manual`,`pe_id`)  VALUES("1","1","14","2","7","100.00000","100.00000",NULL,"0","7");

INSERT INTO payroll_employees_deductions (`id`,`payroll_id`,`name_id`,`deduction_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("1","1","6","1","2","1500.00000","15 days","0","4");
INSERT INTO payroll_employees_deductions (`id`,`payroll_id`,`name_id`,`deduction_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("2","1","14","1","1","500.00000","15 days","0","7");
INSERT INTO payroll_employees_deductions (`id`,`payroll_id`,`name_id`,`deduction_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("3","1","13","1","4","500.00000","15 days","0","10");

INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("1","1","2","1","2","5000.00000","5,000.00 X 1 Month","0","1");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("2","1","3","1","8","5000.00000","5,000.00 X 1 Month","0","2");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("3","1","4","1","1","5000.00000","5,000.00 X 1 Month","0","3");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("4","1","13","2","7","750.00000","750.00 X 1 Month","0","10");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("5","1","9","2","3","1250.00000","1,250.00 X 1 Month","0","11");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("6","1","11","2","5","750.00000","750.00 X 1 Month","0","12");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("7","1","12","2","6","750.00000","750.00 X 1 Month","0","13");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("8","1","10","2","4","750.00000","750.00 X 1 Month","0","14");
INSERT INTO payroll_employees_earnings (`id`,`payroll_id`,`name_id`,`earning_id`,`entry_id`,`amount`,`notes`,`manual`,`pe_id`)  VALUES("16","1","1","1","0","192.32000",NULL,"0","0");

INSERT INTO payroll_employees_salaries (`id`,`payroll_id`,`name_id`,`salary_id`,`amount`,`notes`,`manner`,`rate_per`,`days`,`hours`,`cola`,`annual_days`,`months`,`manual`,`pe_id`)  VALUES("1","1","6","1","10000.00000",NULL,"semi-monthly","month","26","8","0.00000","312","12","0","4");
INSERT INTO payroll_employees_salaries (`id`,`payroll_id`,`name_id`,`salary_id`,`amount`,`notes`,`manner`,`rate_per`,`days`,`hours`,`cola`,`annual_days`,`months`,`manual`,`pe_id`)  VALUES("2","1","7","3","8450.00000",NULL,"daily","month","26","8","0.00000","312","12","0","5");
INSERT INTO payroll_employees_salaries (`id`,`payroll_id`,`name_id`,`salary_id`,`amount`,`notes`,`manner`,`rate_per`,`days`,`hours`,`cola`,`annual_days`,`months`,`manual`,`pe_id`)  VALUES("3","1","8","4","8450.00000",NULL,"daily","month","26","8","0.00000","312","12","0","6");
INSERT INTO payroll_employees_salaries (`id`,`payroll_id`,`name_id`,`salary_id`,`amount`,`notes`,`manner`,`rate_per`,`days`,`hours`,`cola`,`annual_days`,`months`,`manual`,`pe_id`)  VALUES("4","1","14","2","10000.00000",NULL,"semi-monthly","month","26","8","0.00000","312","12","0","7");
INSERT INTO payroll_employees_salaries (`id`,`payroll_id`,`name_id`,`salary_id`,`amount`,`notes`,`manner`,`rate_per`,`days`,`hours`,`cola`,`annual_days`,`months`,`manual`,`pe_id`)  VALUES("5","1","1","5","5000.00000",NULL,"daily","month","26","8","0.00000","312","12","0","9");

INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","3","0","4","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","1","0","3","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","2","0","2","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","1","0","0","2","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","2","0","0","1","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","1","3","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","2","2","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","3","1","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","4","0","1","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","1","0","0","0","3","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","2","0","0","0","2","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","3","0","0","0","1","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","4","0","0","0","2","1");
INSERT INTO payroll_groups (`payroll_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","5","0","0","0","1","1");

INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-01");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-02");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-03");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-04");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-05");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-06");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-07");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-08");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-09");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-10");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-11");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-12");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-13");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-14");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-15");

INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`print_format`,`group_by`,`active`)  VALUES("1","1","15th Payroll","1","1","1",NULL,"group","1");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`print_format`,`group_by`,`active`)  VALUES("2","1","30th Payroll","1","1","1",NULL,"position","1");

INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("1","1","3");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("1","2","2");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("1","3","1");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("2","1","3");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("2","2","2");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("2","3","1");

INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","working_days");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","absences");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","rate_per_day");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","basic_salary");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","cola");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","absences_amount");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","net_pay");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","leave_benefits");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","gross_pay");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","earning_1");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","earning_2");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","benefit_1");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","benefit_2");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","benefit_3");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","deduction_1");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","deduction_2");
INSERT INTO payroll_templates_columns (`template_id`,`term_id`,`column_id`)  VALUES("1","0","deduction_3");

INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("1","1","3");
INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("1","2","2");
INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("2","1","2");
INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("2","2","1");
INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("1","3","1");

INSERT INTO payroll_templates_earnings (`template_id`,`earning_id`,`order`)  VALUES("1","1","2");
INSERT INTO payroll_templates_earnings (`template_id`,`earning_id`,`order`)  VALUES("1","2","1");
INSERT INTO payroll_templates_earnings (`template_id`,`earning_id`,`order`)  VALUES("2","1","2");
INSERT INTO payroll_templates_earnings (`template_id`,`earning_id`,`order`)  VALUES("2","2","1");

INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","13","3","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","9","0","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","13","4","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","2","2","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","3","3","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","4","1","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","2","2","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","6","2","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","7","0","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","8","5","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","14","1","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","11","0","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","12","1","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","10","2","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","9","4","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","3","3","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","4","4","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","6","5","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","7","7","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","8","8","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","14","6","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","10","1","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","11","2","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("2","12","3","none",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","5","0","payslip",NULL,"1",NULL,NULL,NULL,NULL);
INSERT INTO payroll_templates_employees (`template_id`,`name_id`,`order`,`template`,`print_group`,`active`,`status_id`,`group_id`,`position_id`,`area_id`)  VALUES("1","1","4","mbg",NULL,"1",NULL,NULL,NULL,NULL);

INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","4","0","0","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","5","0","0","0","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("2","4","0","0","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("2","5","0","0","0","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","1","0","0","0","3","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","2","0","0","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","3","0","0","0","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","3","0","4","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","1","0","3","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","2","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","1","0","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","2","0","0","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","1","3","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","2","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","3","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","4","0","1","1");

INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("1","1","account","users","login","0",NULL,"2018-10-01 13:44:50","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("2","1","account","users","login","0",NULL,"2018-10-01 13:45:27","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("3","1","account","users","logout","0","Logged Out","2018-10-03 16:52:06","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("4","1","account","users","login","0","Logged In","2018-10-03 16:52:08","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("5","1","account","users","logout","0","Logged Out","2018-10-03 16:52:23","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("6","2","account","users","login","0","Logged In","2018-10-03 16:52:27","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("7","2","account","users","logout","0","Logged Out","2018-10-03 16:52:35","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("8","1","account","users","login","0","Logged In","2018-10-03 16:52:36","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("9","1","account","users","login","0","Logged In","2018-10-04 12:22:26","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("10","1","account","users","login","0","Logged In","2018-10-17 10:07:55","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("11","1","account","users","logout","0","Logged Out","2018-10-17 10:52:09","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("12","1","account","users","login","0","Logged In","2018-10-17 10:52:28","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("13","1","account","users","login","0","Logged In","2018-10-19 09:38:02","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("14","1","account","users","login","0","Logged In","2018-10-23 08:02:01","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("15","1","account","users","logout","0","Logged Out","2018-10-23 08:12:55","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("16","1","account","users","login","0","Logged In","2018-10-23 08:15:18","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("17","1","account","users","login","0","Logged In","2018-10-24 11:35:12","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("18","1","account","users","login","0","Logged In","2018-10-24 12:07:26","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("19","1","account","users","login","0","Logged In","2018-10-26 09:51:22","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("20","1","account","users","login","0","Logged In","2018-10-26 17:24:38","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("21","1","account","users","login","0","Logged In","2018-10-29 08:22:56","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("22","1","account","users","login","0","Logged In","2018-10-29 08:28:44","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("23","1","account","users","login","0","Logged In","2018-10-31 08:01:51","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("24","1","account","users","login","0","Logged In","2019-01-07 09:25:21","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("25","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:28","11");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("26","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:29","5");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("27","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:30","12");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("28","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:31","10");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("29","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:32","4");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("30","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:34","13");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("31","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:35","2");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("32","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:36","7");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("33","1","employees","employees","deactivate","1","Employee Deactivated","2019-01-07 09:26:41","9");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("34","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:43","11");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("35","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:44","5");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("36","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:45","12");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("37","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:46","10");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("38","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:48","4");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("39","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:49","13");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("40","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:50","2");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("41","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:51","7");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("42","1","employees","employees","delete","1","Employee Deactivated","2019-01-07 09:26:52","9");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("43","1","employees","employees","add_multiple","1","Added Multiple Employees","2019-01-07 09:29:36","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("44","1","employees","employees","add_multiple","1","Added Multiple Employees","2019-01-07 09:29:36","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("45","1","employees","employees","edit","1","Edit Employment","2019-01-07 09:29:49","12");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("46","1","employees","employees","edit","1","Edit Employment","2019-01-07 09:29:55","13");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("47","1","employees","employees","add","1","Employee Added: Mark Anthony Monesit","2019-01-07 09:31:28","7");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("48","1","lists","names","add","1","Name Added: shit","2019-01-07 09:31:54","15");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("49","1","account","users","login","0","Logged In","2019-01-07 18:47:40","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("50","1","account","users","login","0","Logged In","2019-01-09 13:38:55","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("51","1","account","users","login","0","Logged In","2019-01-15 11:57:33","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("52","1","account","users","logout","0","Logged Out","2019-01-15 12:04:35","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("53","1","account","users","login","0","Logged In","2019-01-15 12:04:43","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("54","1","account","users","login","0","Logged In","2019-01-15 14:23:24","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("55","1","account","users","login","0","Logged In","2019-01-16 10:40:25","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("56","1","account","users","login","0","Logged In","2019-01-16 16:32:17","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("57","1","account","users","login","0","Logged In","2019-02-09 09:26:15","0");
INSERT INTO system_audit (`id`,`user_id`,`dept`,`sect`,`action`,`company_id`,`notes`,`date_accessed`,`name_id`)  VALUES("58","1","account","users","login","0","Logged In","2019-02-15 17:08:10","0");

INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("1","Regular",NULL,"employment_status","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("2","Contractual",NULL,"employment_status","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("3","Working Student","Working Student","employment_status","0","0");

INSERT INTO user_accounts (`id`,`username`,`password`,`name`,`last_login`)  VALUES("1","alchie","941533a479a78dd89e3dacb0b38641809ed5bfcd","Alchie","2019-02-15 09:08:10");
INSERT INTO user_accounts (`id`,`username`,`password`,`name`,`last_login`)  VALUES("2","admin","941533a479a78dd89e3dacb0b38641809ed5bfcd","Admin","2018-10-03 08:52:27");

INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("1","1");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("2","1");

INSERT INTO user_accounts_options (`uid`,`department`,`section`,`key`,`value`)  VALUES("1","my","settings","theme","_company_theme_");

INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","system","users","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","payroll","payroll","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","payroll","templates","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","employees","employees","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","employees","groups","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","employees","positions","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","employees","areas","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","lists","names","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","lists","benefits","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","lists","earnings","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","lists","deductions","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","system","companies","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","system","terms","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","system","users","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","system","database","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","developer_tools","themes","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","payroll","payroll","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","payroll","templates","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","employees","employees","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","employees","groups","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","employees","positions","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","employees","areas","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","lists","names","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","lists","benefits","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","lists","earnings","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","lists","deductions","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","system","companies","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","system","terms","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","system","database","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","developer_tools","themes","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","reports","13month","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("2","system","audit","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","reports","13month","1","1","1","1");
INSERT INTO user_accounts_restrictions (`uid`,`department`,`section`,`view`,`add`,`edit`,`delete`)  VALUES("1","system","audit","0","0","0","0");

