DROP TABLE account_sessions;

CREATE TABLE `account_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `account_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO account_sessions VALUES("8fbe2568ae236ad5e166fc3237d7f8572bc1b660","127.0.0.1","1489047885","__ci_last_regenerate|i:1489046729;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:17:\"payroll_templates\";");
INSERT INTO account_sessions VALUES("f3c19cbdce93a73fb8f67b4484cac90086f184d7","127.0.0.1","1489047486","__ci_last_regenerate|i:1489047196;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:16:\"system_companies\";");
INSERT INTO account_sessions VALUES("8ce55568b9fc7560aa66f7cc6c26af85bbb887c0","127.0.0.1","1489048739","__ci_last_regenerate|i:1489047550;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:26:\"payroll/print_group/3/ajax\";");
INSERT INTO account_sessions VALUES("f0a0dd057b8eb7f6486ca0cdc6299155a71fefd7","127.0.0.1","1489048138","__ci_last_regenerate|i:1489047911;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:50:\"Archdiocese of Davao Stewardship Apostolates, Inc.\";current_company_id|s:1:\"2\";referrer_uri|s:30:\"payroll_overall/view/6/0/print\";");
INSERT INTO account_sessions VALUES("b282b6ebde8d4b1f9ffbffe484c88ed262675ee8","127.0.0.1","1489048667","__ci_last_regenerate|i:1489048455;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:50:\"Archdiocese of Davao Stewardship Apostolates, Inc.\";current_company_id|s:1:\"2\";referrer_uri|s:30:\"payroll_overall/view/6/0/print\";");
INSERT INTO account_sessions VALUES("acef8b7728f16ea830f7d0d669f08c4666ae65d9","127.0.0.1","1489049096","__ci_last_regenerate|i:1489048741;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:26:\"payroll/print_group/3/ajax\";");
INSERT INTO account_sessions VALUES("704dfb580e9f75f2aa10a76f309acae326b44007","127.0.0.1","1489049186","__ci_last_regenerate|i:1489049100;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:30:\"payroll_overall/view/3/0/print\";");
INSERT INTO account_sessions VALUES("0f0fb38bb71c74de90df581fec0205ad71f390db","127.0.0.1","1489049584","__ci_last_regenerate|i:1489049494;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:30:\"payroll_overall/view/3/2/print\";");
INSERT INTO account_sessions VALUES("d12fa0b637615d6cae227369bb386ee752272243","127.0.0.1","1489049906","__ci_last_regenerate|i:1489049784;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:50:\"Archdiocese of Davao Stewardship Apostolates, Inc.\";current_company_id|s:1:\"2\";referrer_uri|s:30:\"payroll_overall/view/6/0/print\";");
INSERT INTO account_sessions VALUES("33046ba66bf7ec8c2b96323dce5d03f9715f981e","127.0.0.1","1489050138","__ci_last_regenerate|i:1489049916;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:24:\"payroll_overall/view/3/1\";");
INSERT INTO account_sessions VALUES("3a588e0d0cd0bbc719b074fc2cc862059f3376aa","127.0.0.1","1489050445","__ci_last_regenerate|i:1489050229;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:32:\"payroll_overall/view/3/2/payslip\";");
INSERT INTO account_sessions VALUES("02ad289d998b961efac99bdab4a322bcee7148c5","127.0.0.1","1489050844","__ci_last_regenerate|i:1489050449;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:50:\"Archdiocese of Davao Stewardship Apostolates, Inc.\";current_company_id|s:1:\"2\";referrer_uri|s:16:\"system_companies\";");
INSERT INTO account_sessions VALUES("4d089b6de9194b63c7bd6356da83cf87eb9b03cd","127.0.0.1","1489051522","__ci_last_regenerate|i:1489050650;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:28:\"system_companies/edit/2/ajax\";");
INSERT INTO account_sessions VALUES("ea35d490b7a77f5f9fbf2b87e6acea79872df444","127.0.0.1","1489052292","__ci_last_regenerate|i:1489050847;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:16:\"system_companies\";");
INSERT INTO account_sessions VALUES("eb68d08ffeb41d37f0219cc4e9e95f242ca3c461","127.0.0.1","1489051845","__ci_last_regenerate|i:1489051543;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:28:\"system_companies/edit/1/ajax\";current_company_theme|s:6:\"united\";");
INSERT INTO account_sessions VALUES("8aea003ada6744eeb11fd24931ed562f7005d468","127.0.0.1","1489052105","__ci_last_regenerate|i:1489051850;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:15:\"employees_areas\";current_company_theme|s:4:\"yeti\";");
INSERT INTO account_sessions VALUES("21ef6fc316948dbae76953b733024e64d0a50c79","127.0.0.1","1489053072","__ci_last_regenerate|i:1489052170;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:19:\"employees_positions\";current_company_theme|s:4:\"yeti\";");
INSERT INTO account_sessions VALUES("6953260f250a76ba2039e5d89e8ded685a0322c6","127.0.0.1","1489052596","__ci_last_regenerate|i:1489052294;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:16:\"system_companies\";current_company_theme|s:4:\"yeti\";");
INSERT INTO account_sessions VALUES("4869728426a1f4e7347e6f5950ef89366fc1d022","127.0.0.1","1489053031","__ci_last_regenerate|i:1489052599;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:50:\"Archdiocese of Davao Stewardship Apostolates, Inc.\";current_company_id|s:1:\"2\";referrer_uri|s:16:\"employees_groups\";current_company_theme|s:5:\"lumen\";");
INSERT INTO account_sessions VALUES("bb9315fd9a90afcfbeefc39ff1e1306275d9e9ae","127.0.0.1","1489053130","__ci_last_regenerate|i:1489053036;loggedIn|b:1;user_id|s:1:\"1\";username|s:6:\"alchie\";name|s:6:\"Alchie\";session_auth|a:4:{s:6:\"system\";a:4:{s:5:\"users\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"backup\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"terms\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"companies\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:7:\"payroll\";a:2:{s:7:\"payroll\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"templates\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:9:\"employees\";a:4:{s:9:\"employees\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:6:\"groups\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:9:\"positions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:5:\"areas\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}s:5:\"lists\";a:4:{s:5:\"names\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"benefits\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:8:\"earnings\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}s:10:\"deductions\";a:4:{s:4:\"view\";s:1:\"1\";s:3:\"add\";s:1:\"1\";s:4:\"edit\";s:1:\"1\";s:6:\"delete\";s:1:\"1\";}}}menu_module|a:4:{s:6:\"system\";a:4:{i:0;s:5:\"users\";i:1;s:6:\"backup\";i:2;s:5:\"terms\";i:3;s:9:\"companies\";}s:7:\"payroll\";a:2:{i:0;s:7:\"payroll\";i:1;s:9:\"templates\";}s:9:\"employees\";a:4:{i:0;s:9:\"employees\";i:1;s:6:\"groups\";i:2;s:9:\"positions\";i:3;s:5:\"areas\";}s:5:\"lists\";a:4:{i:0;s:5:\"names\";i:1;s:8:\"benefits\";i:2;s:8:\"earnings\";i:3;s:10:\"deductions\";}}user_settings|a:1:{s:5:\"theme\";s:6:\"united\";}current_company|s:40:\"The Roman Catholic Bishop of Davao, Inc.\";current_company_id|s:1:\"1\";referrer_uri|s:13:\"system_backup\";current_company_theme|s:7:\"journal\";");

DROP TABLE benefits_list;

CREATE TABLE `benefits_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `notes` text,
  `leave` int(1) DEFAULT '0',
  `ee_account_title` varchar(200) DEFAULT NULL,
  `er_account_title` varchar(200) DEFAULT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `trash` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO benefits_list VALUES("1","SSS","Social Security System","0",NULL,NULL,"1","0");
INSERT INTO benefits_list VALUES("2","HDMF","Pag-ibig Fund","0",NULL,NULL,"0","0");
INSERT INTO benefits_list VALUES("3","PHIC","PhilHealth","0",NULL,NULL,"1","0");
INSERT INTO benefits_list VALUES("4","Vacation Leave","Vacation Leave","1",NULL,NULL,"1","0");
INSERT INTO benefits_list VALUES("5","Sick Leave","Sick Leave","1",NULL,NULL,"1","0");
INSERT INTO benefits_list VALUES("6","Emergency Leave","Emergency Leave","1",NULL,NULL,"1","0");
INSERT INTO benefits_list VALUES("7","Maternity Leave","Maternity Leave","1",NULL,NULL,"1","0");
INSERT INTO benefits_list VALUES("8","Paternity Leave","Paternity Leave","1",NULL,NULL,"1","0");

DROP TABLE companies_list;

CREATE TABLE `companies_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `notes` text,
  `default` int(1) DEFAULT '0',
  `theme` varchar(50) DEFAULT NULL,
  `trash` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO companies_list VALUES("1","The Roman Catholic Bishop of Davao, Inc.",NULL,NULL,NULL,"1","journal","0");
INSERT INTO companies_list VALUES("2","Archdiocese of Davao Stewardship Apostolates, Inc.",NULL,NULL,NULL,"0","lumen","0");

DROP TABLE deductions_list;

CREATE TABLE `deductions_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `notes` text,
  `account_title` varchar(200) DEFAULT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `trash` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO deductions_list VALUES("1","SSS Loan","SSS Loan",NULL,"1","0");
INSERT INTO deductions_list VALUES("2","HDMF Loan","HDMF Loan",NULL,"1","0");
INSERT INTO deductions_list VALUES("3","WTax","Withholding Tax",NULL,"1","0");
INSERT INTO deductions_list VALUES("4","CA","Cash Advance",NULL,"1","0");
INSERT INTO deductions_list VALUES("5","SLoan","Salary Loan",NULL,"1","0");
INSERT INTO deductions_list VALUES("6","Rice","Rice Loan",NULL,"1","0");

DROP TABLE earnings_list;

CREATE TABLE `earnings_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `notes` text,
  `account_title` varchar(200) DEFAULT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `trash` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO earnings_list VALUES("1","Honorarium","Honorarium",NULL,"1","0");
INSERT INTO earnings_list VALUES("2","Allowance","Allowance",NULL,"1","0");

DROP TABLE employees;

CREATE TABLE `employees` (
  `name_id` int(20) NOT NULL,
  `company_id` int(20) NOT NULL,
  `group_id` int(20) DEFAULT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `position_id` int(20) DEFAULT NULL,
  `area_id` int(20) DEFAULT NULL,
  `hired` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `notes` text,
  `phone_number` varchar(100) DEFAULT NULL,
  `address` text,
  `trash` int(1) NOT NULL DEFAULT '0',
  KEY `name_id` (`name_id`),
  KEY `group_id` (`group_id`),
  KEY `position_id` (`position_id`),
  KEY `area_id` (`area_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO employees VALUES("1","1","1","Amora","Vicente","#","1",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("7","1","4","Anghag","Victoria","#","6",NULL,"2017-02-17",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("2","1","1","Balunos","Leoncio","#","10",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("12","1","1","Barquio","Jonathan","#","10",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("3","1","5","Cal","Rosita","#","2",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("5","1","1","Legitimas","Arnel","#","4",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("4","1","5","Lee","Teresita","#","3",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("9","1","5","Loremas","Ariane Jess","#","7",NULL,"2017-02-17",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("10","1","7","Manila","Erlinda","#","8",NULL,"2017-02-17",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("6","1","5","Remotigue","Jesusa","#","5",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("8","1","1","Sumatra","Marcelino","#","1",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("13","1","5","Tagudin","Chester Alan","#","11",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("11","1","4","Viriña","Chrislyn","#","9",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("15","1","2","Dugos","Agapito","#","13",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("14","1","2","Esteban","Julito","#","12",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("16","1","2","Salarda","Jhunrie","#","13",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("17","1","2","Tolosa","Ricardo","#","13",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("25","1","1","Achacoso","Nelia","#","14",NULL,"2017-02-17",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("24","1","5","Alegro","Siegfred","#","15","0","2017-02-20",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("20","1","1","Amores","Dolores","#","19",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("22","1","1","Arellano","Elan","#","17",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("18","1","2","Asedilla","Catalino","#","13",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("23","1","1","Cabaluna","Carmen","#","16",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("19","1","8","Capitan","Salvacion","#","20","0","2017-02-20",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("21","1","7","Hamot","Teresa","#","18",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("30","1","9","Magulta","Alberto","#","21","0","2017-02-20",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("44","1","10","Alura","Niel John","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("34","1","10","Bangod","Alvin","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("45","1","10","Beron","Jeffrey","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("40","1","10","Bestudio","Jeferson","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("33","1","10","Bustamante","Daban Ricky","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("47","1","10","Dalus","Cyril","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("35","1","10","Escobido","Bryan Rex","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("32","1","10","Farinas","Efren","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("41","1","10","Gantala","Socralito","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("46","1","10","Jumawan","Franievy","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("39","1","10","Magana","John Francis","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("42","1","10","Mula","Jandel","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("37","1","10","Navarre","Danilo","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("38","1","10","Patoy","John Paul","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("43","1","10","Portogalisa","Randy","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("36","1","10","Sandoval","Cris","#","22","0","2017-02-24",NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("28","1","6","Remotigue","Sr. Lourdes","#","0",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("27","1","0","Infiesto","Sr. Ma. Rosario","#","0",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("26","1","1","Morales","Sr. Oliva","#","0",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("29","1","1","Villanueva","Sr. Vilma","#","0",NULL,NULL,NULL,NULL,NULL,NULL,"0");
INSERT INTO employees VALUES("48","2","0","Maghanoy","Jesus Rickson","#","0","0","2017-03-08",NULL,NULL,NULL,NULL,"0");

DROP TABLE employees_absences;

CREATE TABLE `employees_absences` (
  `name_id` int(20) NOT NULL,
  `date_absent` date NOT NULL,
  `hours` int(2) DEFAULT '8',
  `leave_type` int(20) DEFAULT NULL,
  `notes` text,
  KEY `name_id` (`name_id`,`date_absent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO employees_absences VALUES("24","2017-02-13","8","0",NULL);

DROP TABLE employees_areas;

CREATE TABLE `employees_areas` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `notes` text,
  `trash` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO employees_areas VALUES("1","2","asdfasdf1 2","asdfasdfasdfasdf","0");

DROP TABLE employees_benefits;

CREATE TABLE `employees_benefits` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name_id` int(20) NOT NULL,
  `benefit_id` int(20) NOT NULL,
  `employee_share` decimal(30,5) NOT NULL,
  `employer_share` decimal(30,5) NOT NULL,
  `start_date` date DEFAULT NULL,
  `primary` int(1) DEFAULT '0',
  `trash` int(1) DEFAULT '1',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`,`benefit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

INSERT INTO employees_benefits VALUES("1","13","2","240.00000","240.00000","2017-01-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("2","3","2","287.66000","287.66000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("3","4","2","292.16000","292.16000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("4","9","2","242.76000","242.76000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("5","6","2","288.66000","288.66000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("6","7","2","200.00000","200.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("7","11","2","176.80000","176.80000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("8","1","2","206.99000","206.99000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("9","2","2","202.99000","202.99000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("10","22","2","156.00000","156.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("11","12","2","196.80000","196.80000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("12","5","2","197.76000","197.76000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("13","8","2","205.83000","205.83000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("14","10","2","196.80000","196.80000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("15","14","2","174.20000","174.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("16","15","2","177.32000","177.32000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("17","16","2","174.20000","174.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("18","17","2","174.20000","174.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("19","1","1","381.50000","783.50000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("20","1","3","125.00000","125.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("21","2","1","363.30000","746.70000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("22","2","3","125.00000","125.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("23","12","1","363.30000","746.70000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("24","12","3","112.50000","112.50000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("25","5","1","363.30000","746.70000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("26","5","3","112.50000","112.50000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("27","8","1","381.50000","783.50000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("28","8","3","125.00000","125.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("29","22","1","290.70000","599.30000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("30","22","3","100.00000","100.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("31","15","1","327.00000","673.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("32","15","3","100.00000","100.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("33","14","1","308.80000","636.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("34","14","3","100.00000","100.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("35","16","1","308.80000","636.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("36","16","3","100.00000","100.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("37","17","1","308.80000","636.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("38","7","1","363.30000","746.70000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("39","7","3","125.00000","125.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("40","11","1","327.00000","673.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("41","11","3","100.00000","100.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("42","3","1","526.80000","1078.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("43","4","1","526.80000","1078.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("44","6","1","526.80000","1078.20000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("45","9","1","436.00000","894.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("46","13","1","436.00000","894.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("47","3","3","175.00000","175.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("48","4","3","175.00000","175.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("49","6","3","175.00000","175.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("50","9","3","150.00000","150.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("51","13","3","150.00000","150.00000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("52","10","1","363.30000","746.70000","2017-02-01","1","0",NULL);
INSERT INTO employees_benefits VALUES("53","10","3","112.50000","112.50000","2017-02-01","1","0",NULL);

DROP TABLE employees_deductions;

CREATE TABLE `employees_deductions` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name_id` int(20) NOT NULL,
  `deduction_id` int(20) NOT NULL,
  `amount` decimal(30,5) NOT NULL,
  `max_amount` decimal(30,5) NOT NULL,
  `start_date` date DEFAULT NULL,
  `computed` varchar(10) DEFAULT '',
  `active` int(1) DEFAULT '0',
  `trash` int(1) DEFAULT '1',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`,`deduction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

INSERT INTO employees_deductions VALUES("1","13","3","302.55000","0.00000","2017-01-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("2","2","3","234.15000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("3","3","3","156.50000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("4","4","3","530.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("5","5","3","215.85000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("6","6","3","37.35000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("7","7","3","302.55000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("8","9","3","34.85000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("9","10","3","45.90000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("10","11","3","45.90000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("11","15","3","74.30000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("12","16","3","33.15000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("13","3","2","2720.45000","111538.45000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("14","3","5","1000.00000","15000.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("15","4","2","2688.28000","59142.05000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("16","4","5","1100.00000","23752.26000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("17","6","2","2762.75000","124323.53000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("18","6","5","500.00000","28037.04000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("19","1","1","415.31000","415.31000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("20","1","2","1707.15000","69992.95000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("21","1","5","500.00000","20000.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("22","2","2","1505.83000","49692.23000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("23","2","5","1000.00000","41706.74000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("24","5","1","415.30000","10382.61000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("25","5","2","955.30000","14329.50000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("26","8","1","415.30000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("27","8","2","1602.45000","44868.60000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("28","8","5","1300.00000","68955.33000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("29","9","5","1500.00000","38500.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("30","10","5","1000.00000","7000.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("31","11","5","500.00000","4000.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("32","12","2","197.06000","8867.48000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("33","12","5","1400.00000","14531.08000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("34","14","2","659.17000","27025.77000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("35","14","5","500.00000","2500.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("36","15","2","983.99000","32471.51000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("37","15","5","1000.00000","7250.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("38","16","1","369.16000","5537.40000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("39","16","5","700.00000","1580.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("40","17","1","184.58000","184.58000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("41","21","5","500.00000","1500.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("42","22","5","500.00000","7500.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("43","23","5","1700.00000","10161.65000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_deductions VALUES("44","24","5","1750.00000","9106.29000","2017-02-01","month","1","0",NULL);

DROP TABLE employees_earnings;

CREATE TABLE `employees_earnings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name_id` int(20) NOT NULL,
  `earning_id` int(20) NOT NULL,
  `amount` decimal(30,5) NOT NULL,
  `max_amount` decimal(30,5) DEFAULT '0.00000',
  `start_date` date DEFAULT NULL,
  `computed` varchar(10) DEFAULT NULL,
  `active` int(1) DEFAULT '0',
  `trash` int(1) DEFAULT '0',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`,`earning_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO employees_earnings VALUES("1","30","1","2000.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("2","44","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("3","47","2","1500.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("4","34","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("5","45","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("6","40","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("7","33","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("8","35","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("9","32","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("10","41","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("11","46","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("12","39","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("13","42","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("14","37","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("15","36","2","750.00000","0.00000","2017-03-03","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("16","43","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);
INSERT INTO employees_earnings VALUES("17","38","2","750.00000","0.00000","2017-02-01","month","1","0",NULL);

DROP TABLE employees_groups;

CREATE TABLE `employees_groups` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `notes` text,
  `trash` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO employees_groups VALUES("1","0","Bishop\'s Residence",NULL,"0");
INSERT INTO employees_groups VALUES("2","0","Diocese Farms",NULL,"0");
INSERT INTO employees_groups VALUES("3","0","Honorarium-based",NULL,"0");
INSERT INTO employees_groups VALUES("4","0","Pastoral Office",NULL,"0");
INSERT INTO employees_groups VALUES("5","0","Oeconomus / Finance",NULL,"0");
INSERT INTO employees_groups VALUES("6","0","Chancery",NULL,"0");
INSERT INTO employees_groups VALUES("7","0","Oeconomus / Nazareth",NULL,"0");
INSERT INTO employees_groups VALUES("8","0","Oeconomus / Cemetery",NULL,"0");
INSERT INTO employees_groups VALUES("9","0","Retainers Fee",NULL,"0");
INSERT INTO employees_groups VALUES("10","0","Working Scholars",NULL,"0");
INSERT INTO employees_groups VALUES("11","2","asdf asdf asdf asdf asdf",NULL,"0");

DROP TABLE employees_positions;

CREATE TABLE `employees_positions` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `notes` text,
  `trash` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO employees_positions VALUES("1","0","Driver",NULL,"0");
INSERT INTO employees_positions VALUES("2","0","Disbursing Officer",NULL,"0");
INSERT INTO employees_positions VALUES("3","0","Bookkeeper",NULL,"0");
INSERT INTO employees_positions VALUES("4","2","Secretary - Abp.Capalla",NULL,"0");
INSERT INTO employees_positions VALUES("5","0","Cashier",NULL,"0");
INSERT INTO employees_positions VALUES("6","0","Pastoral Secretary",NULL,"0");
INSERT INTO employees_positions VALUES("7","0","Oeconomus Secretary",NULL,"0");
INSERT INTO employees_positions VALUES("8","0","Nazareth RH Manager",NULL,"0");
INSERT INTO employees_positions VALUES("9","0","Pastoral Office Staff",NULL,"0");
INSERT INTO employees_positions VALUES("10","0","House Maintenance",NULL,"0");
INSERT INTO employees_positions VALUES("11","0","Accountant",NULL,"0");
INSERT INTO employees_positions VALUES("12","0","Maintenance Personnel / Beach",NULL,"0");
INSERT INTO employees_positions VALUES("13","0","Farm Worker",NULL,"0");
INSERT INTO employees_positions VALUES("14","0","Cook",NULL,"0");
INSERT INTO employees_positions VALUES("15","0","Finance Staff",NULL,"0");
INSERT INTO employees_positions VALUES("16","0","Laundry Personnel",NULL,"0");
INSERT INTO employees_positions VALUES("17","0","House Assistant Manager",NULL,"0");
INSERT INTO employees_positions VALUES("18","0","Nazareth Personnel",NULL,"0");
INSERT INTO employees_positions VALUES("19","0","Mayordoma",NULL,"0");
INSERT INTO employees_positions VALUES("20","0","Cemetery Incharge",NULL,"0");
INSERT INTO employees_positions VALUES("21","0","Legal Officer",NULL,"0");
INSERT INTO employees_positions VALUES("22","0","Working Scholar",NULL,"0");

DROP TABLE employees_salaries;

CREATE TABLE `employees_salaries` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name_id` int(20) NOT NULL,
  `amount` decimal(30,5) NOT NULL DEFAULT '0.00000',
  `rate_per` varchar(10) NOT NULL DEFAULT 'month',
  `days` int(10) NOT NULL DEFAULT '26',
  `hours` int(10) NOT NULL DEFAULT '8',
  `cola` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `notes` text,
  `primary` int(1) DEFAULT '0',
  `trash` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO employees_salaries VALUES("1","3","14382.88000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("2","4","14607.88000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("3","9","12138.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("4","10","9840.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("5","6","14432.88000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("6","13","12000.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("7","7","10000.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("8","11","8840.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("9","1","10349.70000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("10","2","10149.70000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("11","12","9840.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("12","5","9887.84000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("13","8","10291.70000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("14","15","8866.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("15","14","8710.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("16","16","8710.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("17","17","8710.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("18","18","5907.88000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("19","19","7190.13000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("20","20","7851.08000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("21","21","6000.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("22","22","7800.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("23","23","7851.08000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("24","24","9268.00000","month","26","8","0.00000",NULL,"1","0");
INSERT INTO employees_salaries VALUES("25","25","7800.00000","month","26","8","0.00000",NULL,"1","0");

DROP TABLE names_list;

CREATE TABLE `names_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(200) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `contact_number` varchar(200) DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

INSERT INTO names_list VALUES("1","Amora, Vicente",NULL,NULL,"0");
INSERT INTO names_list VALUES("2","Balunos, Leoncio",NULL,NULL,"0");
INSERT INTO names_list VALUES("3","Cal, Rosita",NULL,NULL,"0");
INSERT INTO names_list VALUES("4","Lee, Teresita",NULL,NULL,"0");
INSERT INTO names_list VALUES("5","Legitimas, Arnel",NULL,NULL,"0");
INSERT INTO names_list VALUES("6","Remotigue, Jesusa",NULL,NULL,"0");
INSERT INTO names_list VALUES("7","Anghag, Victoria",NULL,NULL,"0");
INSERT INTO names_list VALUES("8","Sumatra, Marcelino",NULL,NULL,"0");
INSERT INTO names_list VALUES("9","Loremas, Ariane Jess",NULL,NULL,"0");
INSERT INTO names_list VALUES("10","Manila, Erlinda",NULL,NULL,"0");
INSERT INTO names_list VALUES("11","Viriña, Chrislyn",NULL,NULL,"0");
INSERT INTO names_list VALUES("12","Barquio, Jonathan",NULL,NULL,"0");
INSERT INTO names_list VALUES("13","Tagudin, Chester Alan",NULL,NULL,"0");
INSERT INTO names_list VALUES("14","Esteban, Julito",NULL,NULL,"0");
INSERT INTO names_list VALUES("15","Dugos, Agapito",NULL,NULL,"0");
INSERT INTO names_list VALUES("16","Salarda, Jhunrie",NULL,NULL,"0");
INSERT INTO names_list VALUES("17","Tolosa, Ricardo",NULL,NULL,"0");
INSERT INTO names_list VALUES("18","Asedilla, Catalino",NULL,NULL,"0");
INSERT INTO names_list VALUES("19","Capitan, Salvacion",NULL,NULL,"0");
INSERT INTO names_list VALUES("20","Amores, Dolores",NULL,NULL,"0");
INSERT INTO names_list VALUES("21","Hamot, Teresa",NULL,NULL,"0");
INSERT INTO names_list VALUES("22","Arellano, Elan",NULL,NULL,"0");
INSERT INTO names_list VALUES("23","Cabaluna, Carmen",NULL,NULL,"0");
INSERT INTO names_list VALUES("24","Alegro, Siegfred",NULL,NULL,"0");
INSERT INTO names_list VALUES("25","Achacoso, Nelia",NULL,NULL,"0");
INSERT INTO names_list VALUES("26","Sr. Oliva Morales, OP",NULL,NULL,"0");
INSERT INTO names_list VALUES("27","Sr. Ma. Rosario Infiesto, TDM",NULL,NULL,"0");
INSERT INTO names_list VALUES("28","Sr. Lourdes Remotigue, TDM",NULL,NULL,"0");
INSERT INTO names_list VALUES("29","Sr. Vilma Villanueva, TDM",NULL,NULL,"0");
INSERT INTO names_list VALUES("30","Atty. Alberto Magulta",NULL,NULL,"0");
INSERT INTO names_list VALUES("31","Msgr. Paul A. Cuison",NULL,NULL,"0");
INSERT INTO names_list VALUES("32","Farinas, Efren",NULL,NULL,"0");
INSERT INTO names_list VALUES("33","Bustamante, Daban Ricky",NULL,NULL,"0");
INSERT INTO names_list VALUES("34","Bangod, Alvin",NULL,NULL,"0");
INSERT INTO names_list VALUES("35","Escobido, Bryan Rex",NULL,NULL,"0");
INSERT INTO names_list VALUES("36","Sandoval, Cris",NULL,NULL,"0");
INSERT INTO names_list VALUES("37","Navarre, Danilo",NULL,NULL,"0");
INSERT INTO names_list VALUES("38","Patoy, John Paul",NULL,NULL,"0");
INSERT INTO names_list VALUES("39","Magana, John Francis",NULL,NULL,"0");
INSERT INTO names_list VALUES("40","Bestudio, Jeferson",NULL,NULL,"0");
INSERT INTO names_list VALUES("41","Gantala, Socralito",NULL,NULL,"0");
INSERT INTO names_list VALUES("42","Mula, Jandel",NULL,NULL,"0");
INSERT INTO names_list VALUES("43","Portogalisa, Randy",NULL,NULL,"0");
INSERT INTO names_list VALUES("44","Alura, Niel John",NULL,NULL,"0");
INSERT INTO names_list VALUES("45","Beron, Jeffrey",NULL,NULL,"0");
INSERT INTO names_list VALUES("46","Jumawan, Franievy",NULL,NULL,"0");
INSERT INTO names_list VALUES("47","Dalus, Cyril",NULL,NULL,"0");
INSERT INTO names_list VALUES("48","Maghanoy, Jesus Rickson",NULL,NULL,"0");

DROP TABLE payroll;

CREATE TABLE `payroll` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `template_id` int(20) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO payroll VALUES("1","1","RCBDI - 01/28/17 - 02/12/17","1","2","2017","1");
INSERT INTO payroll VALUES("2","1","RCBDI - 2/13/17 - 2/27/17","2","3","2017","1");
INSERT INTO payroll VALUES("3","1","RCBDI - 2/28/17 - 3/12/17","1","3","2017","1");
INSERT INTO payroll VALUES("4","2","asdfasdf","1","3","2017","1");
INSERT INTO payroll VALUES("5","1","Asdfasdfasdfasdf","1","3","2017","0");
INSERT INTO payroll VALUES("6","2","Asdfasdfdfdddfdfasdf","2","3","2017","1");

DROP TABLE payroll_benefits;

CREATE TABLE `payroll_benefits` (
  `payroll_id` int(20) NOT NULL,
  `benefit_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `benefit_id` (`payroll_id`,`benefit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_benefits VALUES("1","2","1");
INSERT INTO payroll_benefits VALUES("2","1","2");
INSERT INTO payroll_benefits VALUES("2","3","1");
INSERT INTO payroll_benefits VALUES("3","2","1");
INSERT INTO payroll_benefits VALUES("6","1","2");
INSERT INTO payroll_benefits VALUES("6","3","1");

DROP TABLE payroll_deductions;

CREATE TABLE `payroll_deductions` (
  `payroll_id` int(20) NOT NULL,
  `deduction_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `deduction_id` (`payroll_id`,`deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_deductions VALUES("1","1","6");
INSERT INTO payroll_deductions VALUES("1","2","5");
INSERT INTO payroll_deductions VALUES("1","3","4");
INSERT INTO payroll_deductions VALUES("1","4","3");
INSERT INTO payroll_deductions VALUES("1","5","2");
INSERT INTO payroll_deductions VALUES("1","6","1");
INSERT INTO payroll_deductions VALUES("2","1","6");
INSERT INTO payroll_deductions VALUES("2","2","5");
INSERT INTO payroll_deductions VALUES("2","3","4");
INSERT INTO payroll_deductions VALUES("2","4","3");
INSERT INTO payroll_deductions VALUES("2","5","2");
INSERT INTO payroll_deductions VALUES("2","6","1");
INSERT INTO payroll_deductions VALUES("3","1","6");
INSERT INTO payroll_deductions VALUES("3","2","5");
INSERT INTO payroll_deductions VALUES("3","3","4");
INSERT INTO payroll_deductions VALUES("3","4","3");
INSERT INTO payroll_deductions VALUES("3","5","2");
INSERT INTO payroll_deductions VALUES("3","6","1");

DROP TABLE payroll_earnings;

CREATE TABLE `payroll_earnings` (
  `payroll_id` int(20) NOT NULL,
  `earning_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `earning_id` (`payroll_id`,`earning_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_earnings VALUES("1","1","2");
INSERT INTO payroll_earnings VALUES("1","2","1");
INSERT INTO payroll_earnings VALUES("2","1","2");
INSERT INTO payroll_earnings VALUES("2","2","1");
INSERT INTO payroll_earnings VALUES("3","1","2");
INSERT INTO payroll_earnings VALUES("3","2","1");
INSERT INTO payroll_earnings VALUES("6","1","2");
INSERT INTO payroll_earnings VALUES("6","2","1");

DROP TABLE payroll_employees;

CREATE TABLE `payroll_employees` (
  `payroll_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  `template` varchar(20) DEFAULT 'payslip',
  `print_group` int(20) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  KEY `name_id` (`payroll_id`,`name_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_employees VALUES("1","3","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","4","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","9","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","7","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","1","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","2","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","12","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","5","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","10","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","6","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","13","4","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","11","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","8","4","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","15","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","14","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","16","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","17","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("1","24","5","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","25","5","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","20","6","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","22","7","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","23","8","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","21","1","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","18","4","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","19","0","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","30","0","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","44","0","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","34","1","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","45","2","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","40","3","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","33","4","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","47","5","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","35","6","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","32","7","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","41","8","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","46","9","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","39","10","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","42","11","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","37","12","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","38","13","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","43","14","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","36","15","payslip","3","1");
INSERT INTO payroll_employees VALUES("1","26","25","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","29","26","payslip","2","1");
INSERT INTO payroll_employees VALUES("1","28","0","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","1","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","2","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","12","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","5","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","8","4","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","25","5","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","20","6","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","22","7","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","23","8","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","26","25","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","29","26","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","15","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","14","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","16","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","17","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","18","4","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","7","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","11","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","3","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","4","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","9","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","6","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","13","4","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","24","5","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","28","0","payslip",NULL,"1");
INSERT INTO payroll_employees VALUES("2","10","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("2","21","1","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","19","0","payslip","2","1");
INSERT INTO payroll_employees VALUES("2","30","0","cash_voucher","2","1");
INSERT INTO payroll_employees VALUES("2","44","0","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","34","1","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","45","2","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","40","3","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","33","4","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","47","5","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","35","6","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","32","7","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","41","8","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","46","9","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","39","10","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","42","11","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","37","12","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","38","13","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","43","14","payslip","3","1");
INSERT INTO payroll_employees VALUES("2","36","15","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","1","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","2","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","12","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","5","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","8","4","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","25","5","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","20","6","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","22","7","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","23","8","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","26","25","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","29","26","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","15","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","14","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","16","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","17","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","18","4","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","7","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","11","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","3","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","4","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","9","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","6","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","13","4","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","24","5","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","28","0","payslip",NULL,"1");
INSERT INTO payroll_employees VALUES("3","10","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("3","21","1","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","19","0","payslip","2","1");
INSERT INTO payroll_employees VALUES("3","30","0","cash_voucher","2","1");
INSERT INTO payroll_employees VALUES("3","44","0","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","34","1","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","45","2","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","40","3","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","33","4","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","47","5","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","35","6","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","32","7","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","41","8","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","46","9","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","39","10","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","42","11","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","37","12","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","38","13","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","43","14","payslip","3","1");
INSERT INTO payroll_employees VALUES("3","36","15","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","1","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","2","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","12","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","5","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","8","4","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","25","5","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","20","6","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","22","7","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","23","8","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","26","25","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","29","26","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","15","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","14","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","16","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","17","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","18","4","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","7","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","11","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","3","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","4","1","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","9","2","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","6","3","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","13","4","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","24","5","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","28","0","payslip",NULL,"1");
INSERT INTO payroll_employees VALUES("6","10","0","payslip","1","1");
INSERT INTO payroll_employees VALUES("6","21","1","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","19","0","payslip","2","1");
INSERT INTO payroll_employees VALUES("6","30","0","cash_voucher","2","1");
INSERT INTO payroll_employees VALUES("6","44","0","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","34","1","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","45","2","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","40","3","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","33","4","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","47","5","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","35","6","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","32","7","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","41","8","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","46","9","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","39","10","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","42","11","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","37","12","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","38","13","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","43","14","payslip","3","1");
INSERT INTO payroll_employees VALUES("6","36","15","payslip","3","1");

DROP TABLE payroll_employees_benefits;

CREATE TABLE `payroll_employees_benefits` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `payroll_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `benefit_id` int(20) NOT NULL,
  `entry_id` int(20) NOT NULL,
  `employee_share` decimal(30,5) DEFAULT '0.00000',
  `employer_share` decimal(30,5) DEFAULT '0.00000',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`),
  KEY `benefit_id` (`benefit_id`),
  KEY `entry_id` (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;

INSERT INTO payroll_employees_benefits VALUES("1","1","13","2","1","240.00000","240.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("2","1","3","2","2","287.66000","287.66000",NULL);
INSERT INTO payroll_employees_benefits VALUES("3","1","4","2","3","292.16000","292.16000",NULL);
INSERT INTO payroll_employees_benefits VALUES("4","1","9","2","4","242.76000","242.76000",NULL);
INSERT INTO payroll_employees_benefits VALUES("5","1","6","2","5","288.66000","288.66000",NULL);
INSERT INTO payroll_employees_benefits VALUES("6","1","7","2","6","200.00000","200.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("7","1","11","2","7","176.80000","176.80000",NULL);
INSERT INTO payroll_employees_benefits VALUES("8","1","1","2","8","206.99000","206.99000",NULL);
INSERT INTO payroll_employees_benefits VALUES("9","1","2","2","9","202.99000","202.99000",NULL);
INSERT INTO payroll_employees_benefits VALUES("10","1","22","2","10","156.00000","156.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("11","1","12","2","11","196.80000","196.80000",NULL);
INSERT INTO payroll_employees_benefits VALUES("12","1","5","2","12","197.76000","197.76000",NULL);
INSERT INTO payroll_employees_benefits VALUES("13","1","8","2","13","205.83000","205.83000",NULL);
INSERT INTO payroll_employees_benefits VALUES("14","1","10","2","14","196.80000","196.80000",NULL);
INSERT INTO payroll_employees_benefits VALUES("15","1","15","2","16","177.32000","177.32000",NULL);
INSERT INTO payroll_employees_benefits VALUES("16","1","14","2","15","174.20000","174.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("17","1","16","2","17","174.20000","174.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("18","1","17","2","18","174.20000","174.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("19","3","1","2","8","206.99000","206.99000",NULL);
INSERT INTO payroll_employees_benefits VALUES("20","3","2","2","9","202.99000","202.99000",NULL);
INSERT INTO payroll_employees_benefits VALUES("21","3","12","2","11","196.80000","196.80000",NULL);
INSERT INTO payroll_employees_benefits VALUES("22","3","5","2","12","197.76000","197.76000",NULL);
INSERT INTO payroll_employees_benefits VALUES("23","3","8","2","13","205.83000","205.83000",NULL);
INSERT INTO payroll_employees_benefits VALUES("24","3","22","2","10","156.00000","156.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("25","3","15","2","16","177.32000","177.32000",NULL);
INSERT INTO payroll_employees_benefits VALUES("26","3","14","2","15","174.20000","174.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("27","3","16","2","17","174.20000","174.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("28","3","17","2","18","174.20000","174.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("29","3","7","2","6","200.00000","200.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("30","3","11","2","7","176.80000","176.80000",NULL);
INSERT INTO payroll_employees_benefits VALUES("31","3","3","2","2","287.66000","287.66000",NULL);
INSERT INTO payroll_employees_benefits VALUES("32","3","4","2","3","292.16000","292.16000",NULL);
INSERT INTO payroll_employees_benefits VALUES("33","3","9","2","4","242.76000","242.76000",NULL);
INSERT INTO payroll_employees_benefits VALUES("34","3","6","2","5","288.66000","288.66000",NULL);
INSERT INTO payroll_employees_benefits VALUES("35","3","13","2","1","240.00000","240.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("36","3","10","2","14","196.80000","196.80000",NULL);
INSERT INTO payroll_employees_benefits VALUES("37","2","1","1","19","381.50000","783.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("38","2","2","1","21","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("39","2","1","3","20","125.00000","125.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("40","2","2","3","22","125.00000","125.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("41","2","12","1","23","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("42","2","5","1","25","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("43","2","8","1","27","381.50000","783.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("44","2","22","1","29","290.70000","599.30000",NULL);
INSERT INTO payroll_employees_benefits VALUES("45","2","15","1","31","327.00000","673.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("46","2","14","1","33","308.80000","636.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("47","2","16","1","35","308.80000","636.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("48","2","17","1","37","308.80000","636.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("49","2","12","3","24","112.50000","112.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("50","2","5","3","26","112.50000","112.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("51","2","8","3","28","125.00000","125.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("52","2","22","3","30","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("53","2","15","3","32","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("54","2","14","3","34","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("55","2","16","3","36","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("56","2","7","1","38","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("57","2","11","1","40","327.00000","673.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("58","2","7","3","39","125.00000","125.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("59","2","11","3","41","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("60","2","3","1","42","526.80000","1078.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("61","2","4","1","43","526.80000","1078.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("62","2","9","1","45","436.00000","894.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("63","2","6","1","44","526.80000","1078.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("64","2","13","1","46","436.00000","894.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("65","2","3","3","47","175.00000","175.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("66","2","4","3","48","175.00000","175.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("67","2","9","3","50","150.00000","150.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("68","2","6","3","49","175.00000","175.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("69","2","13","3","51","150.00000","150.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("70","2","10","1","52","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("71","2","10","3","53","112.50000","112.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("72","6","1","1","19","381.50000","783.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("73","6","2","1","21","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("74","6","12","1","23","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("75","6","5","1","25","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("76","6","8","1","27","381.50000","783.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("77","6","22","1","29","290.70000","599.30000",NULL);
INSERT INTO payroll_employees_benefits VALUES("78","6","15","1","31","327.00000","673.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("79","6","14","1","33","308.80000","636.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("80","6","16","1","35","308.80000","636.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("81","6","17","1","37","308.80000","636.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("82","6","7","1","38","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("83","6","11","1","40","327.00000","673.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("84","6","3","1","42","526.80000","1078.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("85","6","4","1","43","526.80000","1078.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("86","6","9","1","45","436.00000","894.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("87","6","6","1","44","526.80000","1078.20000",NULL);
INSERT INTO payroll_employees_benefits VALUES("88","6","13","1","46","436.00000","894.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("89","6","10","1","52","363.30000","746.70000",NULL);
INSERT INTO payroll_employees_benefits VALUES("90","6","1","3","20","125.00000","125.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("91","6","2","3","22","125.00000","125.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("92","6","12","3","24","112.50000","112.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("93","6","5","3","26","112.50000","112.50000",NULL);
INSERT INTO payroll_employees_benefits VALUES("94","6","8","3","28","125.00000","125.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("95","6","22","3","30","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("96","6","15","3","32","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("97","6","14","3","34","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("98","6","16","3","36","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("99","6","7","3","39","125.00000","125.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("100","6","11","3","41","100.00000","100.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("101","6","3","3","47","175.00000","175.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("102","6","4","3","48","175.00000","175.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("103","6","9","3","50","150.00000","150.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("104","6","6","3","49","175.00000","175.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("105","6","13","3","51","150.00000","150.00000",NULL);
INSERT INTO payroll_employees_benefits VALUES("106","6","10","3","53","112.50000","112.50000",NULL);

DROP TABLE payroll_employees_deductions;

CREATE TABLE `payroll_employees_deductions` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `payroll_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `deduction_id` int(20) NOT NULL,
  `entry_id` int(20) NOT NULL,
  `amount` decimal(30,5) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`,`payroll_id`,`deduction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8;

INSERT INTO payroll_employees_deductions VALUES("1","1","13","3","1","302.55000",NULL);
INSERT INTO payroll_employees_deductions VALUES("2","1","3","3","3","156.50000",NULL);
INSERT INTO payroll_employees_deductions VALUES("3","1","4","3","4","530.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("4","1","2","3","2","234.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("5","1","9","3","8","34.85000",NULL);
INSERT INTO payroll_employees_deductions VALUES("6","1","6","3","6","37.35000",NULL);
INSERT INTO payroll_employees_deductions VALUES("7","1","7","3","7","302.55000",NULL);
INSERT INTO payroll_employees_deductions VALUES("8","1","11","3","10","45.90000",NULL);
INSERT INTO payroll_employees_deductions VALUES("9","1","5","3","5","215.85000",NULL);
INSERT INTO payroll_employees_deductions VALUES("10","1","10","3","9","45.90000",NULL);
INSERT INTO payroll_employees_deductions VALUES("11","1","15","3","11","74.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("12","1","16","3","12","33.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("13","1","3","2","13","2720.45000",NULL);
INSERT INTO payroll_employees_deductions VALUES("14","1","3","5","14","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("15","1","4","4","0","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("16","1","4","2","15","2688.28000",NULL);
INSERT INTO payroll_employees_deductions VALUES("17","1","4","5","16","1100.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("18","1","4","6","0","1115.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("19","1","6","6","0","1115.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("20","1","6","2","17","2762.75000",NULL);
INSERT INTO payroll_employees_deductions VALUES("21","1","6","5","18","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("22","1","9","6","0","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("23","1","13","6","0","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("24","1","14","6","0","1115.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("25","1","1","1","19","415.31000",NULL);
INSERT INTO payroll_employees_deductions VALUES("26","1","5","1","24","415.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("27","1","8","1","26","415.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("28","1","16","1","38","369.16000",NULL);
INSERT INTO payroll_employees_deductions VALUES("29","1","17","1","40","184.58000",NULL);
INSERT INTO payroll_employees_deductions VALUES("30","1","1","2","20","1707.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("31","1","2","2","22","1505.83000",NULL);
INSERT INTO payroll_employees_deductions VALUES("32","1","12","2","32","197.06000",NULL);
INSERT INTO payroll_employees_deductions VALUES("33","1","5","2","25","955.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("34","1","8","2","27","1602.45000",NULL);
INSERT INTO payroll_employees_deductions VALUES("35","1","15","2","36","983.99000",NULL);
INSERT INTO payroll_employees_deductions VALUES("36","1","14","2","34","659.17000",NULL);
INSERT INTO payroll_employees_deductions VALUES("37","1","9","5","29","1500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("38","1","11","5","31","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("39","1","1","5","21","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("40","1","2","5","23","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("41","1","12","5","33","1400.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("42","1","8","5","28","1300.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("43","1","10","5","30","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("44","1","15","5","37","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("45","1","14","5","35","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("46","1","16","5","39","700.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("47","1","12","4","0","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("48","1","23","4","0","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("49","1","24","5","44","1750.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("50","1","22","5","42","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("51","1","23","5","43","1700.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("52","1","21","5","41","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("53","1","24","6","0","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("54","3","5","1","24","415.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("55","3","8","1","26","415.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("56","3","16","1","38","369.16000",NULL);
INSERT INTO payroll_employees_deductions VALUES("57","3","1","2","20","1707.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("58","3","2","2","22","1505.83000",NULL);
INSERT INTO payroll_employees_deductions VALUES("59","3","12","2","32","197.06000",NULL);
INSERT INTO payroll_employees_deductions VALUES("60","3","5","2","25","955.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("61","3","8","2","27","1602.45000",NULL);
INSERT INTO payroll_employees_deductions VALUES("62","3","15","2","36","983.99000",NULL);
INSERT INTO payroll_employees_deductions VALUES("63","3","14","2","34","659.17000",NULL);
INSERT INTO payroll_employees_deductions VALUES("64","3","3","2","13","2720.45000",NULL);
INSERT INTO payroll_employees_deductions VALUES("65","3","4","2","15","2688.28000",NULL);
INSERT INTO payroll_employees_deductions VALUES("66","3","6","2","17","2762.75000",NULL);
INSERT INTO payroll_employees_deductions VALUES("67","3","2","3","2","234.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("68","3","5","3","5","215.85000",NULL);
INSERT INTO payroll_employees_deductions VALUES("69","3","15","3","11","74.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("70","3","16","3","12","33.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("71","3","7","3","7","302.55000",NULL);
INSERT INTO payroll_employees_deductions VALUES("72","3","11","3","10","45.90000",NULL);
INSERT INTO payroll_employees_deductions VALUES("73","3","3","3","3","156.50000",NULL);
INSERT INTO payroll_employees_deductions VALUES("74","3","4","3","4","530.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("75","3","9","3","8","34.85000",NULL);
INSERT INTO payroll_employees_deductions VALUES("76","3","6","3","6","37.35000",NULL);
INSERT INTO payroll_employees_deductions VALUES("77","3","13","3","1","302.55000",NULL);
INSERT INTO payroll_employees_deductions VALUES("78","3","10","3","9","45.90000",NULL);
INSERT INTO payroll_employees_deductions VALUES("79","3","1","5","21","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("80","3","2","5","23","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("81","3","12","5","33","1400.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("82","3","8","5","28","1300.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("83","3","22","5","42","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("84","3","23","5","43","1700.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("85","3","15","5","37","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("86","3","14","5","35","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("87","3","16","5","39","700.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("88","3","11","5","31","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("89","3","3","5","14","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("90","3","4","5","16","1100.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("91","3","9","5","29","1500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("92","3","6","5","18","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("93","3","24","5","44","1750.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("94","3","10","5","30","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("95","3","21","5","41","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("96","2","5","1","24","415.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("97","2","8","1","26","415.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("98","2","16","1","38","369.16000",NULL);
INSERT INTO payroll_employees_deductions VALUES("99","2","1","2","20","1707.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("100","2","2","2","22","1505.83000",NULL);
INSERT INTO payroll_employees_deductions VALUES("101","2","12","2","32","197.06000",NULL);
INSERT INTO payroll_employees_deductions VALUES("102","2","5","2","25","955.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("103","2","8","2","27","1602.45000",NULL);
INSERT INTO payroll_employees_deductions VALUES("104","2","15","2","36","983.99000",NULL);
INSERT INTO payroll_employees_deductions VALUES("105","2","14","2","34","659.17000",NULL);
INSERT INTO payroll_employees_deductions VALUES("106","2","3","2","13","2720.45000",NULL);
INSERT INTO payroll_employees_deductions VALUES("107","2","4","2","15","2688.28000",NULL);
INSERT INTO payroll_employees_deductions VALUES("108","2","6","2","17","2762.75000",NULL);
INSERT INTO payroll_employees_deductions VALUES("109","2","2","3","2","234.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("110","2","5","3","5","215.85000",NULL);
INSERT INTO payroll_employees_deductions VALUES("111","2","15","3","11","74.30000",NULL);
INSERT INTO payroll_employees_deductions VALUES("112","2","16","3","12","33.15000",NULL);
INSERT INTO payroll_employees_deductions VALUES("113","2","7","3","7","302.55000",NULL);
INSERT INTO payroll_employees_deductions VALUES("114","2","11","3","10","45.90000",NULL);
INSERT INTO payroll_employees_deductions VALUES("115","2","3","3","3","156.50000",NULL);
INSERT INTO payroll_employees_deductions VALUES("116","2","4","3","4","530.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("117","2","9","3","8","34.85000",NULL);
INSERT INTO payroll_employees_deductions VALUES("118","2","6","3","6","37.35000",NULL);
INSERT INTO payroll_employees_deductions VALUES("119","2","13","3","1","302.55000",NULL);
INSERT INTO payroll_employees_deductions VALUES("120","2","10","3","9","45.90000",NULL);
INSERT INTO payroll_employees_deductions VALUES("121","2","1","5","21","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("122","2","2","5","23","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("123","2","12","5","33","1400.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("124","2","8","5","28","1300.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("125","2","22","5","42","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("126","2","23","5","43","1700.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("127","2","15","5","37","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("128","2","14","5","35","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("129","2","16","5","39","180.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("130","2","11","5","31","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("131","2","3","5","14","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("132","2","4","5","16","1100.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("133","2","9","5","29","1500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("134","2","6","5","18","500.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("135","2","24","5","44","1750.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("136","2","10","5","30","1000.00000",NULL);
INSERT INTO payroll_employees_deductions VALUES("137","2","21","5","41","500.00000",NULL);

DROP TABLE payroll_employees_earnings;

CREATE TABLE `payroll_employees_earnings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `payroll_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `earning_id` int(20) NOT NULL,
  `entry_id` int(20) NOT NULL,
  `amount` decimal(30,5) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`,`payroll_id`,`earning_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO payroll_employees_earnings VALUES("1","1","30","1","1","2000.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("2","3","30","1","1","2000.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("3","2","30","1","1","2000.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("4","2","44","2","2","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("5","2","34","2","4","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("6","2","45","2","5","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("7","2","40","2","6","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("8","2","33","2","7","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("9","2","47","2","3","1500.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("10","2","35","2","8","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("11","2","32","2","9","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("12","2","41","2","10","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("13","2","46","2","11","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("14","2","39","2","12","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("15","2","42","2","13","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("16","2","37","2","14","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("17","2","38","2","17","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("18","2","43","2","16","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("19","2","36","2","15","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("20","6","30","1","1","2000.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("21","6","44","2","2","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("22","6","34","2","4","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("23","6","45","2","5","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("24","6","40","2","6","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("25","6","33","2","7","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("26","6","47","2","3","1500.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("27","6","35","2","8","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("28","6","32","2","9","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("29","6","41","2","10","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("30","6","46","2","11","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("31","6","39","2","12","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("32","6","42","2","13","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("33","6","37","2","14","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("34","6","38","2","17","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("35","6","43","2","16","750.00000",NULL);
INSERT INTO payroll_employees_earnings VALUES("36","6","36","2","15","750.00000",NULL);

DROP TABLE payroll_employees_salaries;

CREATE TABLE `payroll_employees_salaries` (
  `payroll_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `salary_id` int(20) NOT NULL,
  `amount` decimal(30,5) DEFAULT '0.00000',
  `notes` text,
  KEY `name_id` (`name_id`),
  KEY `payroll_id` (`payroll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_employees_salaries VALUES("1","3","1","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","4","2","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","9","3","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","10","4","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","6","5","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","13","6","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","7","7","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","11","8","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","1","9","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","2","10","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","12","11","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","5","12","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","8","13","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","15","14","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","14","15","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","16","16","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","17","17","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","24","24","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","25","25","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","20","20","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","22","22","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","23","23","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","21","21","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","18","18","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("1","19","19","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","1","9","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","2","10","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","12","11","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","5","12","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","8","13","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","25","25","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","20","20","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","22","22","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","23","23","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","15","14","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","14","15","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","16","16","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","17","17","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","18","18","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","7","7","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","11","8","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","3","1","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","4","2","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","9","3","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","6","5","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","13","6","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","24","24","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","10","4","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","21","21","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("2","19","19","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","1","9","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","2","10","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","12","11","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","5","12","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","8","13","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","25","25","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","20","20","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","22","22","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","23","23","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","15","14","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","14","15","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","16","16","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","17","17","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","18","18","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","7","7","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","11","8","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","3","1","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","4","2","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","9","3","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","6","5","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","13","6","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","24","24","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","10","4","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","21","21","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("3","19","19","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","1","9","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","2","10","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","12","11","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","5","12","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","8","13","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","25","25","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","20","20","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","22","22","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","23","23","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","15","14","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","14","15","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","16","16","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","17","17","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","18","18","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","7","7","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","11","8","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","3","1","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","4","2","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","9","3","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","6","5","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","13","6","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","24","24","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","10","4","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","21","21","0.00000",NULL);
INSERT INTO payroll_employees_salaries VALUES("6","19","19","0.00000",NULL);

DROP TABLE payroll_groups;

CREATE TABLE `payroll_groups` (
  `payroll_id` int(20) NOT NULL,
  `group_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `group_id` (`payroll_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_groups VALUES("1","5","9");
INSERT INTO payroll_groups VALUES("1","4","8");
INSERT INTO payroll_groups VALUES("1","1","7");
INSERT INTO payroll_groups VALUES("1","7","6");
INSERT INTO payroll_groups VALUES("1","2","5");
INSERT INTO payroll_groups VALUES("1","8","4");
INSERT INTO payroll_groups VALUES("1","9","3");
INSERT INTO payroll_groups VALUES("1","6","2");
INSERT INTO payroll_groups VALUES("1","10","1");
INSERT INTO payroll_groups VALUES("2","1","9");
INSERT INTO payroll_groups VALUES("2","2","8");
INSERT INTO payroll_groups VALUES("2","4","7");
INSERT INTO payroll_groups VALUES("2","5","6");
INSERT INTO payroll_groups VALUES("2","6","5");
INSERT INTO payroll_groups VALUES("2","7","4");
INSERT INTO payroll_groups VALUES("2","8","3");
INSERT INTO payroll_groups VALUES("2","9","2");
INSERT INTO payroll_groups VALUES("2","10","1");
INSERT INTO payroll_groups VALUES("3","1","7");
INSERT INTO payroll_groups VALUES("3","2","5");
INSERT INTO payroll_groups VALUES("3","4","8");
INSERT INTO payroll_groups VALUES("3","5","9");
INSERT INTO payroll_groups VALUES("3","6","2");
INSERT INTO payroll_groups VALUES("3","7","6");
INSERT INTO payroll_groups VALUES("3","8","4");
INSERT INTO payroll_groups VALUES("3","9","3");
INSERT INTO payroll_groups VALUES("3","10","1");
INSERT INTO payroll_groups VALUES("6","1","9");
INSERT INTO payroll_groups VALUES("6","2","8");
INSERT INTO payroll_groups VALUES("6","4","7");
INSERT INTO payroll_groups VALUES("6","5","6");
INSERT INTO payroll_groups VALUES("6","6","5");
INSERT INTO payroll_groups VALUES("6","7","4");
INSERT INTO payroll_groups VALUES("6","8","3");
INSERT INTO payroll_groups VALUES("6","9","2");
INSERT INTO payroll_groups VALUES("6","10","1");

DROP TABLE payroll_inclusive_dates;

CREATE TABLE `payroll_inclusive_dates` (
  `payroll_id` int(20) NOT NULL,
  `inclusive_date` date NOT NULL,
  KEY `payroll_id` (`payroll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-01");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-02");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-03");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-04");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-06");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-07");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-08");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-09");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-10");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-02-11");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-01-28");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-01-30");
INSERT INTO payroll_inclusive_dates VALUES("1","2017-01-31");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-13");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-14");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-15");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-16");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-17");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-18");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-20");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-21");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-22");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-23");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-24");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-25");
INSERT INTO payroll_inclusive_dates VALUES("2","2017-02-27");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-01");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-02");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-03");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-04");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-06");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-07");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-08");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-09");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-10");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-11");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-03-13");
INSERT INTO payroll_inclusive_dates VALUES("3","2017-02-28");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-14");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-15");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-16");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-17");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-18");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-20");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-21");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-22");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-23");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-24");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-25");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-27");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-28");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-29");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-30");
INSERT INTO payroll_inclusive_dates VALUES("6","2017-03-31");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-14");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-15");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-16");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-17");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-18");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-20");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-21");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-22");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-23");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-24");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-25");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-27");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-28");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-29");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-30");
INSERT INTO payroll_inclusive_dates VALUES("5","2017-03-31");

DROP TABLE payroll_templates;

CREATE TABLE `payroll_templates` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `company_name` varchar(200) DEFAULT NULL,
  `company_address` varchar(200) DEFAULT NULL,
  `company_contacts` varchar(200) DEFAULT NULL,
  `checked_by` int(20) DEFAULT NULL,
  `approved_by` int(20) DEFAULT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `checked_by` (`checked_by`,`approved_by`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO payroll_templates VALUES("1","1","15th Payroll - RCBDI","The Roman Catholic Bishop of Davao, Inc.","247 F. Torres St., Davao City","221-1234","13","31","1");
INSERT INTO payroll_templates VALUES("2","1","30th Payroll - RCBDI","The Roman Catholic Bishop of Davao, Inc","247 F. Torres St, Davao City","221-1234","13","31","1");
INSERT INTO payroll_templates VALUES("3","2","15th Payroll",NULL,NULL,NULL,"0","0","1");

DROP TABLE payroll_templates_benefits;

CREATE TABLE `payroll_templates_benefits` (
  `template_id` int(20) NOT NULL,
  `benefit_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `benefit_id` (`template_id`,`benefit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_templates_benefits VALUES("1","2","1");
INSERT INTO payroll_templates_benefits VALUES("2","1","2");
INSERT INTO payroll_templates_benefits VALUES("2","3","1");

DROP TABLE payroll_templates_columns;

CREATE TABLE `payroll_templates_columns` (
  `template_id` int(20) NOT NULL,
  `term_id` int(20) NOT NULL,
  `column_id` varchar(200) NOT NULL,
  KEY `term_id` (`term_id`,`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_templates_columns VALUES("2","0","working_days");
INSERT INTO payroll_templates_columns VALUES("2","0","absences");
INSERT INTO payroll_templates_columns VALUES("2","0","days_present");
INSERT INTO payroll_templates_columns VALUES("2","0","rate_per_day");
INSERT INTO payroll_templates_columns VALUES("2","0","basic_salary");
INSERT INTO payroll_templates_columns VALUES("2","0","cola");
INSERT INTO payroll_templates_columns VALUES("2","0","gross_pay");
INSERT INTO payroll_templates_columns VALUES("2","0","earning_1");
INSERT INTO payroll_templates_columns VALUES("2","0","earning_2");
INSERT INTO payroll_templates_columns VALUES("2","0","benefit_1");
INSERT INTO payroll_templates_columns VALUES("2","0","benefit_2");
INSERT INTO payroll_templates_columns VALUES("2","0","benefit_3");
INSERT INTO payroll_templates_columns VALUES("2","0","deduction_1");
INSERT INTO payroll_templates_columns VALUES("2","0","deduction_2");
INSERT INTO payroll_templates_columns VALUES("2","0","deduction_3");
INSERT INTO payroll_templates_columns VALUES("2","0","deduction_4");
INSERT INTO payroll_templates_columns VALUES("2","0","deduction_5");
INSERT INTO payroll_templates_columns VALUES("2","0","deduction_6");
INSERT INTO payroll_templates_columns VALUES("1","0","working_days");
INSERT INTO payroll_templates_columns VALUES("1","0","absences");
INSERT INTO payroll_templates_columns VALUES("1","0","days_present");
INSERT INTO payroll_templates_columns VALUES("1","0","rate_per_day");
INSERT INTO payroll_templates_columns VALUES("1","0","basic_salary");
INSERT INTO payroll_templates_columns VALUES("1","0","cola");
INSERT INTO payroll_templates_columns VALUES("1","0","gross_pay");
INSERT INTO payroll_templates_columns VALUES("1","0","earning_1");
INSERT INTO payroll_templates_columns VALUES("1","0","earning_2");
INSERT INTO payroll_templates_columns VALUES("1","0","benefit_2");
INSERT INTO payroll_templates_columns VALUES("1","0","benefit_1");
INSERT INTO payroll_templates_columns VALUES("1","0","benefit_3");
INSERT INTO payroll_templates_columns VALUES("1","0","deduction_1");
INSERT INTO payroll_templates_columns VALUES("1","0","deduction_2");
INSERT INTO payroll_templates_columns VALUES("1","0","deduction_3");
INSERT INTO payroll_templates_columns VALUES("1","0","deduction_4");
INSERT INTO payroll_templates_columns VALUES("1","0","deduction_5");
INSERT INTO payroll_templates_columns VALUES("1","0","deduction_6");
INSERT INTO payroll_templates_columns VALUES("2","3","earning_2");
INSERT INTO payroll_templates_columns VALUES("2","3","deduction_4");

DROP TABLE payroll_templates_deductions;

CREATE TABLE `payroll_templates_deductions` (
  `template_id` int(20) NOT NULL,
  `deduction_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `deduction_id` (`template_id`,`deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_templates_deductions VALUES("1","1","6");
INSERT INTO payroll_templates_deductions VALUES("1","2","5");
INSERT INTO payroll_templates_deductions VALUES("1","3","4");
INSERT INTO payroll_templates_deductions VALUES("1","4","3");
INSERT INTO payroll_templates_deductions VALUES("1","5","2");
INSERT INTO payroll_templates_deductions VALUES("1","6","1");

DROP TABLE payroll_templates_earnings;

CREATE TABLE `payroll_templates_earnings` (
  `template_id` int(20) NOT NULL,
  `earning_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `earning_id` (`template_id`,`earning_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_templates_earnings VALUES("1","1","2");
INSERT INTO payroll_templates_earnings VALUES("1","2","1");
INSERT INTO payroll_templates_earnings VALUES("2","1","2");
INSERT INTO payroll_templates_earnings VALUES("2","2","1");

DROP TABLE payroll_templates_employees;

CREATE TABLE `payroll_templates_employees` (
  `template_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  `template` varchar(20) DEFAULT 'payslip',
  `print_group` int(20) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  KEY `name_id` (`template_id`,`name_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_templates_employees VALUES("2","1","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","2","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","12","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","5","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","8","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","25","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","20","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","22","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","23","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","44","2","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","34","0","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","45","1","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","40","3","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","33","4","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","47","5","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","35","6","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","32","7","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","41","8","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","46","9","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","39","10","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","42","11","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","37","12","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","38","13","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","43","14","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","36","15","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("2","26","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","29","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","15","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","14","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","16","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","17","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","18","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","7","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","11","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","3","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","4","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","9","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","6","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","13","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","24","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","28","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","10","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","21","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("2","19","0","payslip",NULL,"1");
INSERT INTO payroll_templates_employees VALUES("1","1","0","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","2","1","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","12","2","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","5","3","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","8","4","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","25","5","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","20","6","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","22","7","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","23","8","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","44","0","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","34","1","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","45","2","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","40","3","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","33","4","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","47","5","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","35","6","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","32","7","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","41","8","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","46","9","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","39","10","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","42","11","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","37","12","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","38","13","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","43","14","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","36","15","payslip","3","1");
INSERT INTO payroll_templates_employees VALUES("1","26","25","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","29","26","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","3","0","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","4","1","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","9","2","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","6","3","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","13","4","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","24","5","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","7","0","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","11","1","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","10","0","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","21","1","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","15","0","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","14","1","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","16","2","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","17","3","payslip","1","1");
INSERT INTO payroll_templates_employees VALUES("1","18","4","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","19","0","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","30","0","payslip","2","1");
INSERT INTO payroll_templates_employees VALUES("1","28","0","payslip","2","0");
INSERT INTO payroll_templates_employees VALUES("2","30","0","cash_voucher","2","1");

DROP TABLE payroll_templates_groups;

CREATE TABLE `payroll_templates_groups` (
  `template_id` int(20) NOT NULL,
  `group_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `template_id` (`template_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO payroll_templates_groups VALUES("1","5","9");
INSERT INTO payroll_templates_groups VALUES("1","4","8");
INSERT INTO payroll_templates_groups VALUES("1","1","7");
INSERT INTO payroll_templates_groups VALUES("1","7","6");
INSERT INTO payroll_templates_groups VALUES("1","2","5");
INSERT INTO payroll_templates_groups VALUES("1","8","4");
INSERT INTO payroll_templates_groups VALUES("1","9","3");
INSERT INTO payroll_templates_groups VALUES("2","1","9");
INSERT INTO payroll_templates_groups VALUES("2","2","8");
INSERT INTO payroll_templates_groups VALUES("2","4","7");
INSERT INTO payroll_templates_groups VALUES("2","5","6");
INSERT INTO payroll_templates_groups VALUES("2","6","5");
INSERT INTO payroll_templates_groups VALUES("2","7","4");
INSERT INTO payroll_templates_groups VALUES("2","8","3");
INSERT INTO payroll_templates_groups VALUES("1","6","2");
INSERT INTO payroll_templates_groups VALUES("1","10","1");
INSERT INTO payroll_templates_groups VALUES("2","9","2");
INSERT INTO payroll_templates_groups VALUES("2","10","1");

DROP TABLE terms_list;

CREATE TABLE `terms_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `notes` text,
  `type` varchar(50) DEFAULT NULL,
  `trash` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO terms_list VALUES("1","Regular Employees",NULL,"print_group","0");
INSERT INTO terms_list VALUES("2","Honorarium Based",NULL,"print_group","0");
INSERT INTO terms_list VALUES("3","Working Scholars",NULL,"print_group","0");

DROP TABLE user_accounts;

CREATE TABLE `user_accounts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO user_accounts VALUES("1","alchie","941533a479a78dd89e3dacb0b38641809ed5bfcd","Alchie");
INSERT INTO user_accounts VALUES("2","jess","6dfd4edc219212e16a48e529e223c6b55512c22f","Jess");

DROP TABLE user_accounts_options;

CREATE TABLE `user_accounts_options` (
  `uid` int(20) NOT NULL,
  `department` varchar(200) NOT NULL,
  `section` varchar(200) NOT NULL,
  `key` varchar(200) NOT NULL,
  `value` text NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO user_accounts_options VALUES("1","my","settings","theme","united");
INSERT INTO user_accounts_options VALUES("2","my","settings","theme","united");

DROP TABLE user_accounts_restrictions;

CREATE TABLE `user_accounts_restrictions` (
  `uid` int(20) NOT NULL,
  `department` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `view` int(1) NOT NULL DEFAULT '0',
  `add` int(1) NOT NULL DEFAULT '0',
  `edit` int(1) NOT NULL DEFAULT '0',
  `delete` int(1) NOT NULL DEFAULT '0',
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO user_accounts_restrictions VALUES("1","system","users","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","payroll","payroll","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","payroll","templates","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","employees","employees","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","employees","groups","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","employees","positions","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","lists","names","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","lists","benefits","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","lists","earnings","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","lists","deductions","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","system","users","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","system","backup","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","payroll","payroll","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","payroll","templates","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","employees","employees","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","employees","groups","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","employees","positions","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","lists","names","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","lists","benefits","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","lists","earnings","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","lists","deductions","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","system","backup","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","employees","areas","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","system","terms","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","employees","areas","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","system","terms","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("2","system","companies","1","1","1","1");
INSERT INTO user_accounts_restrictions VALUES("1","system","companies","1","1","1","1");

