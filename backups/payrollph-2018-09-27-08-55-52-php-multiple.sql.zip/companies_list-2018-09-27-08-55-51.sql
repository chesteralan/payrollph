INSERT INTO companies_list (`id`,`theme`,`name`,`address`,`phone`,`notes`,`default`,`trash`)  VALUES("1","yeti","Archdiocesan Nourishment Center","Pag-asa St, Fatima, Davao City","082-285-1524",NULL,"1","0");

