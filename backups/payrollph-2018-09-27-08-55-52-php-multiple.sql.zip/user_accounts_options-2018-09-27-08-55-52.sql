INSERT INTO user_accounts_options (`uid`,`department`,`section`,`key`,`value`)  VALUES("1","my","settings","theme","_company_theme_");

