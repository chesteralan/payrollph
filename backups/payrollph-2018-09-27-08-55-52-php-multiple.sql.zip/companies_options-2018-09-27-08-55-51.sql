INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_employees","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_dtr","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_salaries","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_earnings","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_benefits","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_deductions","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_summary","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("1","column_group_sort","a:7:{i:0;s:22:\"column_group_employees\";i:1;s:16:\"column_group_dtr\";i:2;s:21:\"column_group_salaries\";i:3;s:21:\"column_group_earnings\";i:4;s:21:\"column_group_benefits\";i:5;s:23:\"column_group_deductions\";i:6;s:20:\"column_group_summary\";}");

