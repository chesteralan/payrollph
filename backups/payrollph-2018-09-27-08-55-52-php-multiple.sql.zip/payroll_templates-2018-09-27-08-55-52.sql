INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`print_format`,`group_by`,`active`)  VALUES("1","1","15th Payroll","1","1","1",NULL,"position","1");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`print_format`,`group_by`,`active`)  VALUES("2","1","30th Payroll","1","1","1",NULL,"position","1");

