INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("1","1","2");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("1","2","1");

