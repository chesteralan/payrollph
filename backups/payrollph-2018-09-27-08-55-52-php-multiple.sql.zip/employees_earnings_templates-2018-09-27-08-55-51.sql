INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("1","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("1","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("2","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("2","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("3","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("3","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("4","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("4","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("5","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("5","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("6","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("6","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("7","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("7","2");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("8","1");
INSERT INTO employees_earnings_templates (`ee_id`,`template_id`)  VALUES("8","2");

