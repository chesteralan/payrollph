INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("1","1","2");
INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("1","2","1");
INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("2","1","2");
INSERT INTO payroll_templates_deductions (`template_id`,`deduction_id`,`order`)  VALUES("2","2","1");

