INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","4","0","0","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","5","0","0","0","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("2","4","0","0","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("2","5","0","0","0","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","1","0","0","0","3","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","2","0","0","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","3","0","0","0","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","3","0","4","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","1","0","3","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","2","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","1","0","0","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","2","0","0","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","1","3","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","2","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","0","3","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`area_id`,`position_id`,`status_id`,`order`,`page`)  VALUES("1","0","0","4","0","1","1");

