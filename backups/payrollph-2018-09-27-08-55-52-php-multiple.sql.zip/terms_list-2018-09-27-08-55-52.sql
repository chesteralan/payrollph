INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("1","Regular",NULL,"employment_status","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("2","Contractual",NULL,"employment_status","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("3","Working Student","Working Student","employment_status","0","0");

