INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("1","0","Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("2","0","Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("3","0","Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("4","1","Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("5","1","Working Students",NULL,"0");

