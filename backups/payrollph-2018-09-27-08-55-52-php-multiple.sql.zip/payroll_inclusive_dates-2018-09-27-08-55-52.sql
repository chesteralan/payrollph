INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-01");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-02");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-03");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-04");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-05");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-06");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-07");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-08");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-09");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-10");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-11");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-12");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-13");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-14");
INSERT INTO payroll_inclusive_dates (`payroll_id`,`inclusive_date`)  VALUES("1","2018-01-15");

