INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("1","1","7","4","15","2018");
INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("2","1","14","4","15","2018");
INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("3","1","6","4","15","2018");
INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("4","1","1","4","15","2018");
INSERT INTO employees_leave_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`days`,`year`)  VALUES("5","1","8","4","15","2018");

