INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("1","1","14","1","500.00000","5000.00000","2018-01-07","month","1","0",NULL);
INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("2","1","6","1","1500.00000","15000.00000","2018-01-07","month","1","0",NULL);
INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("3","1","8","1","2000.00000","10000.00000","2018-02-07","month","1","0",NULL);
INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("4","1","13","1","500.00000","4000.00000","2018-01-01","month","1","0",NULL);
INSERT INTO employees_deductions (`id`,`company_id`,`name_id`,`deduction_id`,`amount`,`max_amount`,`start_date`,`computed`,`active`,`trash`,`notes`)  VALUES("5","1","14","1","500.00000","15000.00000","2018-01-24","month","1","0",NULL);

