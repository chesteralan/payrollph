INSERT INTO payroll_deductions (`payroll_id`,`deduction_id`,`order`)  VALUES("1","1","2");
INSERT INTO payroll_deductions (`payroll_id`,`deduction_id`,`order`)  VALUES("1","2","1");

