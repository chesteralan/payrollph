INSERT INTO names_meta (`meta_id`,`name_id`,`meta_key`,`meta_value`)  VALUES("1","1","sgl_number","123-456-789");
INSERT INTO names_meta (`meta_id`,`name_id`,`meta_key`,`meta_value`)  VALUES("2","1","sgl_expiry","09/14/2018");
INSERT INTO names_meta (`meta_id`,`name_id`,`meta_key`,`meta_value`)  VALUES("3","1","sgl_status","expired");

