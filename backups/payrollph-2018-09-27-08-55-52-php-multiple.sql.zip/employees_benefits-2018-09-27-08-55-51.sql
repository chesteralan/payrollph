INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("1","1","6","1","165.00000","165.00000","2018-01-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("2","1","14","1","165.00000","165.00000","2018-01-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("3","1","3","1","165.00000","165.00000","2018-01-07","1","1",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("4","1","8","1","165.00000","165.00000","2018-01-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("5","1","7","1","165.00000","165.00000","2018-01-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("6","1","6","2","100.00000","100.00000","2018-02-07","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("7","1","14","2","100.00000","100.00000","1970-01-01","1","0",NULL);
INSERT INTO employees_benefits (`id`,`company_id`,`name_id`,`benefit_id`,`employee_share`,`employer_share`,`start_date`,`primary`,`trash`,`notes`)  VALUES("8","1","7","2","100.00000","100.00000","2018-02-07","1","0",NULL);

