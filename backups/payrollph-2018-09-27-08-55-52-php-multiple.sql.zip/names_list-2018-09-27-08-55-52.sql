INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("1","Chester Alan Tagudin","Mintal","+639462559955","0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("2","Sr. Ma. Felina Inting, LGC",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("3","Sr. Melodia Tabucal, LGC",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("4","Sr. Edna Dailisan, LGC",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("5","Sr. Essa",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("6","Teddy Romero",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("7","Mark Anthony Monesit",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("8","Narcisa Tanudra",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("9","Winston Mula",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("10","PJ Capuno",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("11","Reneboy",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("12","Jophord Aclo",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("13","Jemmar Galacio",NULL,NULL,"0");
INSERT INTO names_list (`id`,`full_name`,`address`,`contact_number`,`trash`)  VALUES("14","Chester Jake Potal",NULL,NULL,"0");

