INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("1","1");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("2","1");

