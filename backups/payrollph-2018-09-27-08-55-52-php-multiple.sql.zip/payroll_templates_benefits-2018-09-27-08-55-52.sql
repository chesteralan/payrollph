INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("1","1","3");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("1","2","2");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("1","3","1");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("2","1","3");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("2","2","2");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("2","3","1");

