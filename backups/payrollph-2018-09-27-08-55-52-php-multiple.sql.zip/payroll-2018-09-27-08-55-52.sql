INSERT INTO payroll (`id`,`company_id`,`name`,`template_id`,`month`,`year`,`active`,`lock`,`print_format`,`group_by`,`checked_by`,`approved_by`)  VALUES("1","1","January 1-15, 2018","1","1","2018","1","0",NULL,"position","1","1");

