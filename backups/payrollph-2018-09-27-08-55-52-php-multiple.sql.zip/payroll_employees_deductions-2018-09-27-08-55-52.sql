INSERT INTO payroll_employees_deductions (`id`,`payroll_id`,`name_id`,`deduction_id`,`entry_id`,`amount`,`notes`,`manual`)  VALUES("1","1","6","1","2","1500.00000","15 days","0");
INSERT INTO payroll_employees_deductions (`id`,`payroll_id`,`name_id`,`deduction_id`,`entry_id`,`amount`,`notes`,`manual`)  VALUES("2","1","14","1","1","500.00000","15 days","0");
INSERT INTO payroll_employees_deductions (`id`,`payroll_id`,`name_id`,`deduction_id`,`entry_id`,`amount`,`notes`,`manual`)  VALUES("3","1","13","1","4","500.00000","15 days","0");

