INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("1","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("2","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("3","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("4","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("5","2");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("6","1");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("7","1");
INSERT INTO employees_benefits_templates (`eb_id`,`template_id`)  VALUES("8","1");

