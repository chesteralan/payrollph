INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("1","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("1","2");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("2","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("2","2");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("3","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("3","2");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("4","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("4","2");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("5","1");
INSERT INTO employees_deductions_templates (`ed_id`,`template_id`)  VALUES("5","2");

