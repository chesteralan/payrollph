INSERT INTO payroll_templates_earnings (`template_id`,`earning_id`,`order`)  VALUES("1","1","2");
INSERT INTO payroll_templates_earnings (`template_id`,`earning_id`,`order`)  VALUES("1","2","1");
INSERT INTO payroll_templates_earnings (`template_id`,`earning_id`,`order`)  VALUES("2","1","2");
INSERT INTO payroll_templates_earnings (`template_id`,`earning_id`,`order`)  VALUES("2","2","1");

