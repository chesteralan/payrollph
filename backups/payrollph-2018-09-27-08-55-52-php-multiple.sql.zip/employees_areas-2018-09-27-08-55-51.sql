INSERT INTO employees_areas (`id`,`company_id`,`trash`,`notes`,`name`)  VALUES("1","1","0",NULL,"Fatima");
INSERT INTO employees_areas (`id`,`company_id`,`trash`,`notes`,`name`)  VALUES("2","1","0",NULL,"Bucana");

