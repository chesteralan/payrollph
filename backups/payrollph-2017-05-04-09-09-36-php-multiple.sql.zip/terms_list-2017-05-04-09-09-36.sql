INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`)  VALUES("1","Regular",NULL,"print_group","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`)  VALUES("2","Honorarium Based",NULL,"print_group","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`)  VALUES("3","Working Scholars",NULL,"print_group","0");

