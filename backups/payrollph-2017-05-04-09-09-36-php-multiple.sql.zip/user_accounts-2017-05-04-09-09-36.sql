INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("1","alchie","a94a8fe5ccb19ba61c4c0873d391e987982fbbd3","Alchie");
INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("2","jess","6dfd4edc219212e16a48e529e223c6b55512c22f","Ariane Jess Loremas");

