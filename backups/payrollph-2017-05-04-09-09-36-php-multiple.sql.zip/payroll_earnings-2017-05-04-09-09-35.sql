INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("1","1","2");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("1","2","1");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("2","1","2");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("2","2","1");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("3","1","2");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("3","2","1");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("4","1","2");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("4","2","1");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("5","1","2");
INSERT INTO payroll_earnings (`payroll_id`,`earning_id`,`order`)  VALUES("5","2","1");

