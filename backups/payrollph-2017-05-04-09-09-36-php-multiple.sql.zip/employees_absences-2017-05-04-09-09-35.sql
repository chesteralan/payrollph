INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("24","2017-02-13","8","0",NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("18","2017-02-28","8","0",NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("18","2017-03-01","8","0",NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("18","2017-03-02","4","0",NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("24","2017-02-28","8","0",NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("24","2017-03-01","8","0",NULL);

