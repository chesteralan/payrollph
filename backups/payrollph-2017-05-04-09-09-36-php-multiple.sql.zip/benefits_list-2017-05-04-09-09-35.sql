INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`)  VALUES("1","SSS","Social Security System","0",NULL,NULL,"1","0");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`)  VALUES("2","HDMF","Pag-ibig Fund","0",NULL,NULL,"0","0");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`)  VALUES("3","PHIC","PhilHealth","0",NULL,NULL,"1","0");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`)  VALUES("4","Vacation Leave","Vacation Leave","1",NULL,NULL,"1","0");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`)  VALUES("5","Sick Leave","Sick Leave","1",NULL,NULL,"1","0");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`)  VALUES("6","Emergency Leave","Emergency Leave","1",NULL,NULL,"1","0");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`)  VALUES("7","Maternity Leave","Maternity Leave","1",NULL,NULL,"1","0");
INSERT INTO benefits_list (`id`,`name`,`notes`,`leave`,`ee_account_title`,`er_account_title`,`active`,`trash`)  VALUES("8","Paternity Leave","Paternity Leave","1",NULL,NULL,"1","0");

