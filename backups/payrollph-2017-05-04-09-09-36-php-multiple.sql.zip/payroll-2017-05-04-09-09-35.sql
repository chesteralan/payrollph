INSERT INTO payroll (`id`,`company_id`,`name`,`template_id`,`month`,`year`,`active`)  VALUES("1","1","RCBDI - 01/28/17 - 02/12/17","1","2","2017","1");
INSERT INTO payroll (`id`,`company_id`,`name`,`template_id`,`month`,`year`,`active`)  VALUES("2","1","RCBDI - 2/13/17 - 2/27/17","2","3","2017","1");
INSERT INTO payroll (`id`,`company_id`,`name`,`template_id`,`month`,`year`,`active`)  VALUES("3","1","RCBDI - 2/28/17 - 3/12/17","1","3","2017","1");
INSERT INTO payroll (`id`,`company_id`,`name`,`template_id`,`month`,`year`,`active`)  VALUES("4","2","February 28 - March 12, 2017","3","3","2017","1");
INSERT INTO payroll (`id`,`company_id`,`name`,`template_id`,`month`,`year`,`active`)  VALUES("5","1","3/13/17 - 3/29/15","2","3","2017","1");

