-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees_positions`
--

DROP TABLE IF EXISTS `employees_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_positions` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `notes` text,
  `trash` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_positions`
--

LOCK TABLES `employees_positions` WRITE;
/*!40000 ALTER TABLE `employees_positions` DISABLE KEYS */;
INSERT INTO `employees_positions` VALUES (1,1,'Driver',NULL,0),(2,1,'Disbursing Officer',NULL,0),(3,1,'Bookkeeper',NULL,0),(4,1,'Secretary - Abp.Capalla',NULL,0),(5,1,'Cashier',NULL,0),(6,1,'Pastoral Secretary',NULL,0),(7,1,'Oeconomus Secretary',NULL,0),(8,1,'Nazareth RH Manager',NULL,0),(9,1,'Pastoral Office Staff',NULL,0),(10,1,'House Maintenance',NULL,0),(11,1,'Accountant',NULL,0),(12,1,'Maintenance Personnel / Beach',NULL,0),(13,1,'Farm Worker',NULL,0),(14,1,'Cook',NULL,0),(15,1,'Finance Staff',NULL,0),(16,1,'Laundry Personnel',NULL,0),(17,1,'House Assistant Manager',NULL,0),(18,1,'Nazareth Personnel',NULL,0),(19,1,'Mayordoma',NULL,0),(20,1,'Cemetery Incharge',NULL,0),(21,1,'Legal Officer',NULL,0),(22,1,'Working Scholar',NULL,0),(23,1,'Receptionist',NULL,0),(24,1,'Chancellor Secretary',NULL,0),(25,1,'Tribunal Secretary',NULL,0),(26,1,'Secretariate Secretary',NULL,0),(27,2,'Caritas Bldg Incharge',NULL,0),(28,2,'Fatima Bldg Head',NULL,0),(29,2,'Araullo Bldg Guard / Maintenance',NULL,0),(30,2,'Fatima Bldg Staff',NULL,0),(31,2,'Fatima Bldg Guard / Maintenance',NULL,0),(32,2,'Araullo Bldg Cashier',NULL,0),(33,2,'Araullo Bldg Canteen Manager',NULL,0);
/*!40000 ALTER TABLE `employees_positions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:05
