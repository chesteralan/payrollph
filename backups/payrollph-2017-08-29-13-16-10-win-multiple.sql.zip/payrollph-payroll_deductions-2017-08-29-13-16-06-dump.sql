-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payroll_deductions`
--

DROP TABLE IF EXISTS `payroll_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_deductions` (
  `payroll_id` int(20) NOT NULL,
  `deduction_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  KEY `deduction_id` (`payroll_id`,`deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_deductions`
--

LOCK TABLES `payroll_deductions` WRITE;
/*!40000 ALTER TABLE `payroll_deductions` DISABLE KEYS */;
INSERT INTO `payroll_deductions` VALUES (1,1,6),(1,2,5),(1,3,4),(1,4,3),(1,5,2),(1,6,1),(2,1,6),(2,2,5),(2,3,4),(2,4,3),(2,5,2),(2,6,1),(3,1,6),(3,2,5),(3,3,4),(3,4,3),(3,5,2),(3,6,1),(4,1,6),(4,2,5),(4,3,4),(4,4,3),(4,5,2),(4,6,1),(5,1,6),(5,2,5),(5,3,4),(5,4,3),(5,5,2),(5,6,1),(6,1,6),(6,2,5),(6,3,4),(6,4,3),(6,5,2),(6,6,1),(7,1,6),(7,2,5),(7,3,4),(7,4,3),(7,5,2),(7,6,1),(8,1,6),(8,2,5),(8,3,4),(8,4,3),(8,5,2),(8,6,1),(9,1,6),(9,2,5),(9,3,4),(9,4,3),(9,5,2),(9,6,1),(10,1,6),(10,2,5),(10,3,4),(10,4,3),(10,5,2),(10,6,1),(11,1,6),(11,2,5),(11,3,4),(11,4,3),(11,5,2),(11,6,1),(12,1,6),(12,2,5),(12,3,4),(12,4,3),(12,5,2),(12,6,1),(13,5,1),(14,1,6),(14,2,5),(14,3,4),(14,4,3),(14,5,2),(14,6,1),(15,1,6),(15,2,5),(15,3,4),(15,4,3),(15,5,2),(15,6,1),(16,1,6),(16,2,5),(16,3,4),(16,4,3),(16,5,2),(16,6,1),(17,5,1),(18,1,6),(18,2,5),(18,3,4),(18,4,3),(18,5,2),(18,6,1),(19,1,6),(19,2,5),(19,3,4),(19,4,3),(19,5,2),(19,6,1),(20,5,1),(23,1,6),(23,2,5),(23,3,4),(23,4,3),(23,5,2),(23,6,1),(24,1,6),(24,2,5),(24,3,4),(24,4,3),(24,5,2),(24,6,1),(25,5,1),(26,1,6),(26,2,5),(26,3,4),(26,4,3),(26,5,2),(26,6,1),(28,5,1),(29,1,6),(29,2,5),(29,3,4),(29,4,3),(29,5,2),(29,6,1),(27,1,6),(27,2,5),(27,3,4),(27,4,3),(27,5,2),(27,6,1),(31,1,6),(31,2,5),(31,3,4),(31,4,3),(31,5,2),(31,6,1),(32,1,6),(32,2,5),(32,3,4),(32,4,3),(32,5,2),(32,6,1);
/*!40000 ALTER TABLE `payroll_deductions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:06
