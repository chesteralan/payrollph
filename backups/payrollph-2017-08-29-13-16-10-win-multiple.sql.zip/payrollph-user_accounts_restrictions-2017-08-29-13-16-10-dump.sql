-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_accounts_restrictions`
--

DROP TABLE IF EXISTS `user_accounts_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_accounts_restrictions` (
  `uid` int(20) NOT NULL,
  `department` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `view` int(1) NOT NULL DEFAULT '0',
  `add` int(1) NOT NULL DEFAULT '0',
  `edit` int(1) NOT NULL DEFAULT '0',
  `delete` int(1) NOT NULL DEFAULT '0',
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_accounts_restrictions`
--

LOCK TABLES `user_accounts_restrictions` WRITE;
/*!40000 ALTER TABLE `user_accounts_restrictions` DISABLE KEYS */;
INSERT INTO `user_accounts_restrictions` VALUES (1,'system','users',1,1,1,1),(2,'payroll','payroll',1,1,1,1),(2,'payroll','templates',1,1,1,1),(2,'employees','employees',1,1,1,1),(2,'employees','groups',1,1,1,1),(2,'employees','positions',1,1,1,1),(2,'lists','names',1,1,1,1),(2,'lists','benefits',1,1,1,1),(2,'lists','earnings',1,1,1,1),(2,'lists','deductions',1,1,1,1),(2,'system','users',1,1,1,1),(2,'system','backup',1,1,1,1),(1,'payroll','payroll',1,1,1,1),(1,'payroll','templates',1,1,1,1),(1,'employees','employees',1,1,1,1),(1,'employees','groups',1,1,1,1),(1,'employees','positions',1,1,1,1),(1,'lists','names',1,1,1,1),(1,'lists','benefits',1,1,1,1),(1,'lists','earnings',1,1,1,1),(1,'lists','deductions',1,1,1,1),(1,'system','backup',1,1,1,1),(2,'employees','areas',1,1,1,1),(2,'system','terms',1,1,1,1),(1,'employees','areas',1,1,1,1),(1,'system','terms',1,1,1,1),(2,'system','companies',1,1,1,1),(1,'system','companies',1,1,1,1),(3,'payroll','payroll',1,1,1,1),(3,'payroll','templates',1,1,1,1),(3,'employees','employees',1,1,1,1),(3,'employees','groups',1,1,1,1),(3,'employees','positions',1,1,1,1),(3,'employees','areas',1,1,1,1),(3,'lists','names',1,1,1,0),(3,'lists','benefits',1,1,1,0),(3,'lists','earnings',1,1,1,0),(3,'lists','deductions',1,1,1,0),(3,'system','companies',0,0,0,0),(3,'system','terms',0,0,0,0),(3,'system','users',0,0,0,0),(3,'system','backup',1,1,1,1),(3,'developer_tools','themes',0,0,0,0);
/*!40000 ALTER TABLE `user_accounts_restrictions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:10
