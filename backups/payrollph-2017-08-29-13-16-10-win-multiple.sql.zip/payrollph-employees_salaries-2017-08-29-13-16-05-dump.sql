-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees_salaries`
--

DROP TABLE IF EXISTS `employees_salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_salaries` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `amount` decimal(30,5) NOT NULL DEFAULT '0.00000',
  `rate_per` varchar(10) NOT NULL DEFAULT 'month',
  `days` int(10) NOT NULL DEFAULT '26',
  `hours` int(10) NOT NULL DEFAULT '8',
  `cola` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `notes` text,
  `primary` int(1) DEFAULT '0',
  `trash` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_salaries`
--

LOCK TABLES `employees_salaries` WRITE;
/*!40000 ALTER TABLE `employees_salaries` DISABLE KEYS */;
INSERT INTO `employees_salaries` VALUES (1,1,3,14382.88000,'month',26,8,0.00000,NULL,1,0),(2,1,4,14607.88000,'month',26,8,0.00000,NULL,1,0),(3,1,9,12138.00000,'month',26,8,0.00000,NULL,1,0),(4,1,10,9840.00000,'month',26,8,0.00000,NULL,1,0),(5,1,6,14432.88000,'month',26,8,0.00000,NULL,1,0),(6,1,13,12000.00000,'month',26,8,0.00000,NULL,1,0),(7,1,7,10000.00000,'month',26,8,0.00000,NULL,1,0),(8,1,11,8840.00000,'month',26,8,0.00000,NULL,1,0),(9,1,1,10349.70000,'month',26,8,0.00000,NULL,1,0),(10,1,2,10149.70000,'month',26,8,0.00000,NULL,1,0),(11,1,12,9840.00000,'month',26,8,0.00000,NULL,1,0),(12,1,5,9887.84000,'month',26,8,0.00000,NULL,1,0),(13,1,8,10291.70000,'month',26,8,0.00000,NULL,1,0),(14,1,15,8866.00000,'month',26,8,0.00000,NULL,1,0),(15,1,14,8710.00000,'month',26,8,0.00000,NULL,1,0),(16,1,16,8710.00000,'month',26,8,0.00000,NULL,1,0),(17,1,17,8710.00000,'month',26,8,0.00000,NULL,1,0),(18,1,18,5907.88000,'month',26,8,0.00000,NULL,1,0),(19,1,19,7190.13000,'month',26,8,0.00000,NULL,1,0),(20,1,20,7851.08000,'month',26,8,0.00000,NULL,1,0),(21,1,21,6000.00000,'month',26,8,0.00000,NULL,1,0),(22,1,22,7800.00000,'month',26,8,0.00000,NULL,1,0),(23,1,23,7851.08000,'month',26,8,0.00000,NULL,1,0),(24,1,24,9268.00000,'month',26,8,0.00000,NULL,0,0),(25,1,25,7800.00000,'month',26,8,0.00000,NULL,1,0),(26,2,49,8840.00000,'month',26,8,0.00000,NULL,1,0),(27,2,48,10184.70000,'month',26,8,0.00000,NULL,1,0),(28,2,51,10000.00000,'month',26,8,0.00000,NULL,1,0),(29,2,50,8840.00000,'month',26,8,0.00000,NULL,1,0),(30,3,54,10000.00000,'month',26,8,0.00000,NULL,1,0),(31,4,57,8888.55000,'month',26,8,0.00000,NULL,1,1),(32,4,58,8888.55000,'month',26,8,0.00000,NULL,1,1),(33,2,61,6000.00000,'month',26,8,0.00000,NULL,1,1),(34,1,24,10000.00000,'month',26,8,0.00000,NULL,1,0);
/*!40000 ALTER TABLE `employees_salaries` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:05
