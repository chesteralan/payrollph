-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payroll_templates_columns`
--

DROP TABLE IF EXISTS `payroll_templates_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_templates_columns` (
  `template_id` int(20) NOT NULL,
  `term_id` int(20) NOT NULL,
  `column_id` varchar(200) NOT NULL,
  KEY `term_id` (`term_id`,`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_templates_columns`
--

LOCK TABLES `payroll_templates_columns` WRITE;
/*!40000 ALTER TABLE `payroll_templates_columns` DISABLE KEYS */;
INSERT INTO `payroll_templates_columns` VALUES (2,0,'working_days'),(2,0,'absences'),(2,0,'days_present'),(2,0,'rate_per_day'),(2,0,'basic_salary'),(2,0,'gross_pay'),(2,0,'earning_1'),(2,0,'earning_2'),(2,0,'benefit_1'),(2,0,'benefit_2'),(2,0,'benefit_3'),(2,0,'deduction_1'),(2,0,'deduction_2'),(2,0,'deduction_3'),(2,0,'deduction_4'),(2,0,'deduction_5'),(2,0,'deduction_6'),(1,0,'working_days'),(1,0,'absences'),(1,0,'days_present'),(1,0,'rate_per_day'),(1,0,'basic_salary'),(1,0,'gross_pay'),(1,0,'earning_1'),(1,0,'earning_2'),(1,0,'benefit_2'),(1,0,'benefit_1'),(1,0,'benefit_3'),(1,0,'deduction_1'),(1,0,'deduction_2'),(1,0,'deduction_3'),(1,0,'deduction_4'),(1,0,'deduction_5'),(1,0,'deduction_6'),(1,2,'working_days'),(1,2,'absences'),(1,2,'days_present'),(1,2,'rate_per_day'),(1,2,'basic_salary'),(1,2,'gross_pay'),(1,2,'earning_1'),(1,2,'earning_2'),(1,2,'benefit_2'),(1,2,'benefit_1'),(1,2,'benefit_3'),(1,2,'deduction_1'),(1,2,'deduction_2'),(1,2,'deduction_3'),(1,2,'deduction_4'),(1,2,'deduction_5'),(1,2,'deduction_6'),(1,1,'working_days'),(1,1,'absences'),(1,1,'days_present'),(1,1,'rate_per_day'),(1,1,'basic_salary'),(1,1,'gross_pay'),(1,1,'earning_1'),(1,1,'earning_2'),(1,1,'benefit_2'),(1,1,'benefit_1'),(1,1,'benefit_3'),(1,1,'deduction_1'),(1,1,'deduction_2'),(1,1,'deduction_3'),(1,1,'deduction_4'),(1,1,'deduction_5'),(1,1,'deduction_6'),(1,3,'earning_2'),(1,3,'deduction_4'),(2,2,'working_days'),(2,2,'absences'),(2,2,'days_present'),(2,2,'rate_per_day'),(2,2,'basic_salary'),(2,2,'gross_pay'),(2,2,'earning_1'),(2,2,'earning_2'),(2,2,'benefit_1'),(2,2,'benefit_3'),(2,2,'benefit_2'),(2,2,'deduction_1'),(2,2,'deduction_2'),(2,2,'deduction_3'),(2,2,'deduction_4'),(2,2,'deduction_5'),(2,2,'deduction_6'),(2,1,'working_days'),(2,1,'absences'),(2,1,'days_present'),(2,1,'rate_per_day'),(2,1,'basic_salary'),(2,1,'gross_pay'),(2,1,'earning_1'),(2,1,'earning_2'),(2,1,'benefit_1'),(2,1,'benefit_3'),(2,1,'benefit_2'),(2,1,'deduction_1'),(2,1,'deduction_2'),(2,1,'deduction_3'),(2,1,'deduction_4'),(2,1,'deduction_5'),(2,1,'deduction_6'),(2,3,'earning_2'),(1,0,'absences_amount'),(1,2,'absences_amount'),(1,1,'absences_amount'),(2,0,'absences_amount'),(2,2,'absences_amount'),(2,1,'absences_amount'),(4,0,'working_days'),(4,0,'absences'),(4,0,'days_present'),(4,0,'rate_per_day'),(4,0,'basic_salary'),(4,0,'cola'),(4,0,'absences_amount'),(4,0,'gross_pay'),(4,0,'earning_1'),(4,0,'earning_2'),(4,0,'benefit_1'),(4,0,'benefit_3'),(4,0,'benefit_2'),(4,0,'deduction_1'),(4,0,'deduction_2'),(4,0,'deduction_3'),(4,0,'deduction_4'),(4,0,'deduction_5'),(4,0,'deduction_6'),(4,2,'working_days'),(4,2,'absences'),(4,2,'days_present'),(4,2,'rate_per_day'),(4,2,'basic_salary'),(4,2,'cola'),(4,2,'absences_amount'),(4,2,'gross_pay'),(4,2,'earning_1'),(4,2,'earning_2'),(4,2,'benefit_1'),(4,2,'benefit_3'),(4,2,'benefit_2'),(4,2,'deduction_1'),(4,2,'deduction_2'),(4,2,'deduction_3'),(4,2,'deduction_4'),(4,2,'deduction_5'),(4,2,'deduction_6'),(4,1,'working_days'),(4,1,'absences'),(4,1,'days_present'),(4,1,'rate_per_day'),(4,1,'basic_salary'),(4,1,'cola'),(4,1,'absences_amount'),(4,1,'gross_pay'),(4,1,'earning_1'),(4,1,'earning_2'),(4,1,'benefit_1'),(4,1,'benefit_3'),(4,1,'benefit_2'),(4,1,'deduction_1'),(4,1,'deduction_2'),(4,1,'deduction_3'),(4,1,'deduction_4'),(4,1,'deduction_5'),(4,1,'deduction_6'),(4,3,'working_days'),(4,3,'absences'),(4,3,'days_present'),(4,3,'rate_per_day'),(4,3,'basic_salary'),(4,3,'cola'),(4,3,'absences_amount'),(4,3,'gross_pay'),(4,3,'earning_1'),(4,3,'earning_2'),(4,3,'benefit_1'),(4,3,'benefit_3'),(4,3,'benefit_2'),(4,3,'deduction_1'),(4,3,'deduction_2'),(4,3,'deduction_3'),(4,3,'deduction_4'),(4,3,'deduction_5'),(4,3,'deduction_6'),(3,0,'working_days'),(3,0,'absences'),(3,0,'days_present'),(3,0,'rate_per_day'),(3,0,'basic_salary'),(3,0,'cola'),(3,0,'absences_amount'),(3,0,'gross_pay'),(3,0,'earning_1'),(3,0,'earning_2'),(3,0,'benefit_2'),(3,0,'benefit_1'),(3,0,'benefit_3'),(3,0,'deduction_1'),(3,0,'deduction_2'),(3,0,'deduction_3'),(3,0,'deduction_4'),(3,0,'deduction_5'),(3,0,'deduction_6'),(3,2,'working_days'),(3,2,'absences'),(3,2,'days_present'),(3,2,'rate_per_day'),(3,2,'basic_salary'),(3,2,'cola'),(3,2,'absences_amount'),(3,2,'gross_pay'),(3,2,'earning_1'),(3,2,'earning_2'),(3,2,'benefit_2'),(3,2,'benefit_1'),(3,2,'benefit_3'),(3,2,'deduction_1'),(3,2,'deduction_2'),(3,2,'deduction_3'),(3,2,'deduction_4'),(3,2,'deduction_5'),(3,2,'deduction_6'),(3,1,'working_days'),(3,1,'absences'),(3,1,'days_present'),(3,1,'rate_per_day'),(3,1,'basic_salary'),(3,1,'cola'),(3,1,'absences_amount'),(3,1,'gross_pay'),(3,1,'earning_1'),(3,1,'earning_2'),(3,1,'benefit_2'),(3,1,'benefit_1'),(3,1,'benefit_3'),(3,1,'deduction_1'),(3,1,'deduction_2'),(3,1,'deduction_3'),(3,1,'deduction_4'),(3,1,'deduction_5'),(3,1,'deduction_6'),(3,3,'working_days'),(3,3,'absences'),(3,3,'days_present'),(3,3,'rate_per_day'),(3,3,'basic_salary'),(3,3,'cola'),(3,3,'absences_amount'),(3,3,'gross_pay'),(3,3,'earning_1'),(3,3,'earning_2'),(3,3,'benefit_2'),(3,3,'benefit_1'),(3,3,'benefit_3'),(3,3,'deduction_1'),(3,3,'deduction_2'),(3,3,'deduction_3'),(3,3,'deduction_4'),(3,3,'deduction_5'),(3,3,'deduction_6'),(6,0,'working_days'),(6,0,'absences'),(6,0,'rate_per_day'),(6,0,'basic_salary'),(6,0,'cola'),(6,0,'absences_amount'),(6,0,'gross_pay'),(6,0,'earning_1'),(6,0,'earning_2'),(6,0,'benefit_1'),(6,0,'benefit_2'),(6,0,'benefit_3'),(6,0,'deduction_5'),(6,0,'deduction_1'),(6,0,'deduction_2'),(6,0,'deduction_3'),(6,0,'deduction_4'),(6,0,'deduction_6'),(5,0,'working_days'),(5,0,'absences'),(5,0,'rate_per_day'),(5,0,'basic_salary'),(5,0,'cola'),(5,0,'absences_amount'),(5,0,'gross_pay'),(5,0,'earning_1'),(5,0,'earning_2'),(5,0,'benefit_1'),(5,0,'benefit_2'),(5,0,'benefit_3'),(5,0,'deduction_5'),(5,0,'deduction_1'),(5,0,'deduction_2'),(5,0,'deduction_3'),(5,0,'deduction_4'),(5,0,'deduction_6'),(8,0,'earning_1');
/*!40000 ALTER TABLE `payroll_templates_columns` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:08
