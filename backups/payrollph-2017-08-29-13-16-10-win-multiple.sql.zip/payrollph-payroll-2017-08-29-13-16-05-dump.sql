-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payroll`
--

DROP TABLE IF EXISTS `payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `template_id` int(20) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '1',
  `lock` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll`
--

LOCK TABLES `payroll` WRITE;
/*!40000 ALTER TABLE `payroll` DISABLE KEYS */;
INSERT INTO `payroll` VALUES (1,1,'RCBDI - 01/28/17 - 02/12/17',1,2,2017,1,1),(2,1,'RCBDI - 2/13/17 - 2/27/17',2,2,2017,1,1),(3,1,'RCBDI - 2/28/17 - 3/12/17',1,3,2017,1,1),(4,2,'February 28 - March 12, 2017',3,3,2017,1,0),(5,1,'3/13/17 - 3/27/15',2,3,2017,1,1),(6,2,'March 13-27,2017',4,3,2017,1,0),(7,1,'3/28/17 - 4/12/17',1,4,2017,1,1),(8,2,'March 28-April 12,2017',3,4,2017,1,0),(9,1,'04/13/17 - 04/27/17',2,4,2017,1,1),(10,2,'04/13/17 - 04/27/17',4,4,2017,1,0),(11,1,'4/28/17 - 5/12/17',1,5,2017,1,1),(12,2,'April 28 - May 12, 2017',3,5,2017,1,0),(13,3,'May 16-30 2017',6,5,2017,1,0),(14,1,'May 13 - 27, 2017',2,5,2017,1,1),(15,2,'May 13 - 27, 2017',4,5,2017,1,0),(16,1,'May 28 - June 12, 2017',1,6,2017,1,1),(17,3,'June 1-15 2017',5,6,2017,1,0),(18,2,'May 28 - June 12, 2017',3,6,2017,1,0),(19,1,'June 13-27, 2017',2,6,2017,1,1),(20,3,'June 15-30 2017',6,6,2017,1,0),(21,4,'June 15-30 2017',7,6,2017,0,0),(22,4,'June 1-30 2017',8,6,2017,1,0),(23,2,'June 13-27, 2017',4,6,2017,1,0),(24,1,'June 28-July 12, 2017',1,7,2017,1,1),(25,3,'July 1-15 2017',5,7,2017,1,0),(26,2,'June 28 - July 12, 2017',3,7,2017,1,0),(27,1,'July 13-27, 2017',2,7,2017,1,1),(28,3,'July 16-30 2017',6,7,2017,1,0),(29,2,'July 13-27, 2017',4,7,2017,1,0),(30,4,'july 1-30 2017',8,7,2017,1,0),(31,1,'July 28-Aug.12,2017',1,8,2017,1,0),(32,2,'July 28-Aug.12,2017',3,8,2017,1,0);
/*!40000 ALTER TABLE `payroll` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:06
