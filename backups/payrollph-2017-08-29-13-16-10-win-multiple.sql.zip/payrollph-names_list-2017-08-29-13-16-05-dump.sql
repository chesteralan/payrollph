-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `names_list`
--

DROP TABLE IF EXISTS `names_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `names_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(200) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `contact_number` varchar(200) DEFAULT NULL,
  `trash` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `names_list`
--

LOCK TABLES `names_list` WRITE;
/*!40000 ALTER TABLE `names_list` DISABLE KEYS */;
INSERT INTO `names_list` VALUES (1,'Amora, Vicente',NULL,NULL,0),(2,'Balunos, Leoncio',NULL,NULL,0),(3,'Cal, Rosita',NULL,NULL,0),(4,'Lee, Teresita',NULL,NULL,0),(5,'Legitimas, Arnel',NULL,NULL,0),(6,'Remotigue, Jesusa',NULL,NULL,0),(7,'Anghag, Victoria',NULL,NULL,0),(8,'Sumatra, Marcelino',NULL,NULL,0),(9,'Loremas, Ariane Jess',NULL,NULL,0),(10,'Manila, Erlinda',NULL,NULL,0),(11,'Viriña, Chrislyn',NULL,NULL,0),(12,'Barquio, Jonathan',NULL,NULL,0),(13,'Tagudin, Chester Alan',NULL,NULL,0),(14,'Esteban, Julito',NULL,NULL,0),(15,'Dugos, Agapito',NULL,NULL,0),(16,'Salarda, Jhunrie',NULL,NULL,0),(17,'Tolosa, Ricardo',NULL,NULL,0),(18,'Asedilla, Catalino',NULL,NULL,0),(19,'Capitan, Salvacion',NULL,NULL,0),(20,'Amores, Dolores',NULL,NULL,0),(21,'Hamot, Teresa',NULL,NULL,0),(22,'Arellano, Elan',NULL,NULL,0),(23,'Cabaluna, Carmen',NULL,NULL,0),(24,'Alegro, Siegfred',NULL,NULL,0),(25,'Achacoso, Nelia',NULL,NULL,0),(26,'Sr. Oliva Morales, OP',NULL,NULL,0),(27,'Sr. Ma. Rosario Infiesto, TDM',NULL,NULL,0),(28,'Sr. Lourdes Remotigue, TDM',NULL,NULL,0),(29,'Sr. Vilma Villanueva, TDM',NULL,NULL,0),(30,'Atty. Alberto Magulta',NULL,NULL,0),(31,'Msgr. Paul A. Cuison',NULL,NULL,0),(32,'Farinas, Efren',NULL,NULL,0),(33,'Bustamante, Daban Ricky',NULL,NULL,0),(34,'Bangod, Alvin',NULL,NULL,0),(35,'Escobido, Bryan Rex',NULL,NULL,0),(36,'Sandoval, Cris',NULL,NULL,0),(37,'Navarre, Danilo',NULL,NULL,0),(38,'Patoy, John Paul',NULL,NULL,0),(39,'Magana, John Francis',NULL,NULL,0),(40,'Bestudio, Jeferson',NULL,NULL,0),(41,'Gantala, Socralito',NULL,NULL,0),(42,'Mula, Jandel',NULL,NULL,0),(43,'Portogalisa, Randy',NULL,NULL,0),(44,'Alura, Niel John',NULL,NULL,0),(45,'Beron, Jeffrey',NULL,NULL,0),(46,'Jumawan, Franievy',NULL,NULL,0),(47,'Dalus, Cyril',NULL,NULL,0),(48,'Maghanoy, Jesus Ricson',NULL,NULL,0),(49,'Aventurado, Lilia',NULL,NULL,0),(50,'Wapano, Ruby',NULL,NULL,0),(51,'Paragas, Christopher',NULL,NULL,0),(52,'Aure, Jimmy',NULL,NULL,0),(53,'Empimo, Lourdes',NULL,NULL,0),(54,'Roferos, Gloria','Mintal Davao City','09216839172',0),(55,'Aclo, Jophord',NULL,NULL,0),(56,'Dela Cruz, Samuel',NULL,NULL,0),(57,'Sr. Elaine Marie D. Difuntorum, OSB',NULL,NULL,0),(58,'Sr. Ma. Lydia Perales, TDM.',NULL,NULL,0),(59,'Jhun Anthony Repollo',NULL,NULL,0),(60,'Jason Alcasid',NULL,NULL,0),(61,'Puno, Evelyn T.','Purok 9A, Madapo Hills',NULL,0);
/*!40000 ALTER TABLE `names_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:05
