-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `name_id` int(20) NOT NULL,
  `company_id` int(20) NOT NULL,
  `group_id` int(20) DEFAULT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `position_id` int(20) DEFAULT NULL,
  `area_id` int(20) DEFAULT NULL,
  `hired` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `notes` text,
  `phone_number` varchar(100) DEFAULT NULL,
  `address` text,
  `trash` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name_id`),
  KEY `name_id` (`name_id`),
  KEY `group_id` (`group_id`),
  KEY `position_id` (`position_id`),
  KEY `area_id` (`area_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,1,1,'Amora','Vicente','#',1,0,'2017-05-12','4',NULL,NULL,NULL,0),(2,1,1,'Balunos','Leoncio','#',10,0,'2017-05-12','4',NULL,NULL,NULL,0),(3,1,5,'Cal','Rosita','#',2,0,'2017-05-12','4',NULL,NULL,NULL,0),(4,1,5,'Lee','Teresita','#',3,0,'2017-05-12','4',NULL,NULL,NULL,0),(5,1,1,'Legitimas','Arnel','#',4,0,'2017-05-12','4',NULL,NULL,NULL,0),(6,1,5,'Remotigue','Jesusa','#',5,0,'2017-05-12','4',NULL,NULL,NULL,0),(7,1,4,'Anghag','Victoria','#',6,0,'2017-02-17','7',NULL,NULL,NULL,0),(8,1,1,'Sumatra','Marcelino','#',1,0,'2017-05-12','4',NULL,NULL,NULL,0),(9,1,5,'Loremas','Ariane Jess','#',7,0,'2017-02-17','4',NULL,NULL,NULL,0),(10,1,7,'Manila','Erlinda','#',8,0,'2017-02-17','4',NULL,NULL,NULL,0),(11,1,4,'Salud','Chrislyn','V.',9,0,'2017-05-12','4',NULL,NULL,NULL,0),(12,1,1,'Barquio','Jonathan','#',10,0,'2017-05-12','4',NULL,NULL,NULL,0),(13,1,5,'Tagudin','Chester Alan','#',11,0,'2017-05-12','4',NULL,NULL,NULL,0),(14,1,2,'Esteban','Julito','Montera',12,0,'2017-05-12','4',NULL,NULL,NULL,0),(15,1,2,'Dugos','Agapito','#',13,0,'2017-05-12','4',NULL,NULL,NULL,0),(16,1,2,'Salarda','Jhunrie','#',13,0,'2017-05-12','4',NULL,NULL,NULL,0),(17,1,2,'Tolosa','Ricardo','#',13,0,'2017-05-12','4',NULL,NULL,NULL,0),(18,1,2,'Asedilla','Catalino','#',13,0,'2017-05-12','7',NULL,NULL,NULL,0),(19,1,8,'Capitan','Salvacion','#',20,0,'2017-02-20','7',NULL,NULL,NULL,0),(20,1,1,'Amores','Dolores','#',19,0,'2017-05-12','7',NULL,NULL,NULL,0),(21,1,7,'Hamot','Teresa','#',18,0,'2017-05-12','7',NULL,NULL,NULL,0),(22,1,1,'Arellano','Elan','#',17,0,'2017-05-12','7',NULL,NULL,NULL,0),(23,1,1,'Cabaluna','Carmen','#',16,0,'2017-05-12','7',NULL,NULL,NULL,0),(24,1,5,'Alegro','Siegfred','B.',15,0,'2017-02-20','4',NULL,NULL,NULL,0),(25,1,1,'Achacoso','Nelia','#',14,0,'2017-02-17','7',NULL,NULL,NULL,0),(26,1,6,'Morales','Sr. Oliva','#',23,0,'2017-03-03','7',NULL,NULL,NULL,0),(27,1,6,'Infiesto','Sr. Ma. Rosario','#',25,0,'2017-03-03','7',NULL,NULL,NULL,0),(28,1,6,'Remotigue','Sr. Lourdes','#',24,0,'2017-03-03','7',NULL,NULL,NULL,0),(29,1,6,'Villanueva','Sr. Vilma','#',26,0,'2017-03-03','7',NULL,NULL,NULL,0),(30,1,9,'Magulta','Alberto','#',21,0,'2017-02-20',NULL,NULL,NULL,NULL,0),(32,1,10,'Farinas','Efren','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(33,1,10,'Bustamante','Daban Ricky','#',22,0,'2017-02-24','6',NULL,NULL,NULL,1),(34,1,10,'Bangod','Alvin','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(35,1,10,'Escobido','Bryan Rex','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(36,1,10,'Sandoval','Cris','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(37,1,10,'Navarre','Danilo','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(38,1,10,'Patoy','John Paul','#',22,0,'2017-02-24','6',NULL,NULL,NULL,1),(39,1,10,'Magana','John Francis','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(40,1,10,'Bestudio','Jeferson','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(41,1,10,'Gantala','Socralito','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(42,1,10,'Mula','Jandel','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(43,1,10,'Portogalisa','Randy','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(44,1,10,'Alura','Niel John','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(45,1,10,'Beron','Jeffrey','#',22,0,'2017-02-24','6',NULL,NULL,NULL,1),(46,1,10,'Jumawan','Franievy','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(47,1,10,'Dalus','Cyril','#',22,0,'2017-02-24','6',NULL,NULL,NULL,0),(48,2,12,'Maghanoy','Jesus Ricson','#',27,0,'2017-03-13',NULL,NULL,NULL,NULL,0),(49,2,12,'Aventurado','Lilia','#',28,0,NULL,NULL,NULL,NULL,NULL,0),(50,2,12,'Wapano','Ruby','#',30,0,NULL,NULL,NULL,NULL,NULL,0),(51,2,12,'Paragas','Christopher','#',29,0,NULL,NULL,NULL,NULL,NULL,0),(52,2,13,'Aure','Jimmy','#',31,0,NULL,NULL,NULL,NULL,NULL,0),(53,2,13,'Empimo','Lourdes','#',32,0,NULL,NULL,NULL,NULL,NULL,0),(54,3,15,'Roferos','Gloria','#',0,0,'2017-05-13','0',NULL,NULL,NULL,0),(55,1,10,'Aclo','Jophord','#',22,0,'2017-06-16','6',NULL,NULL,NULL,0),(56,1,10,'Dela Cruz','Samuel','#',22,0,NULL,NULL,NULL,NULL,NULL,0),(57,4,16,'Difuntorum','Sr. Elaine Marie','D',0,0,'2017-06-27','7',NULL,NULL,NULL,0),(58,4,16,'Perales','Sr. Ma. Lydia','#',0,0,'2017-06-27','7',NULL,NULL,NULL,0),(59,1,10,'Repollo','Jhun Anthony','#',22,0,NULL,NULL,NULL,NULL,NULL,0),(60,1,10,'Alcasid','Jason','#',22,0,'2017-07-12','6',NULL,NULL,NULL,0),(61,2,13,'Puno','Evelyn','T',33,0,'2017-07-17','5',NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:02
