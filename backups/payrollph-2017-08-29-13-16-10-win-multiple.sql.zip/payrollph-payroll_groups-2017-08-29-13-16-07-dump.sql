-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payroll_groups`
--

DROP TABLE IF EXISTS `payroll_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_groups` (
  `payroll_id` int(20) NOT NULL,
  `group_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  `page` int(2) DEFAULT '1',
  KEY `group_id` (`payroll_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_groups`
--

LOCK TABLES `payroll_groups` WRITE;
/*!40000 ALTER TABLE `payroll_groups` DISABLE KEYS */;
INSERT INTO `payroll_groups` VALUES (1,5,9,1),(1,4,8,1),(1,1,7,1),(1,7,6,1),(1,2,5,1),(1,8,4,1),(1,9,3,1),(1,6,2,1),(1,10,1,1),(2,1,9,1),(2,2,4,1),(2,4,5,1),(2,5,8,1),(2,6,7,1),(2,7,3,1),(2,8,2,1),(2,10,1,1),(3,1,8,1),(3,2,5,1),(3,4,6,1),(3,5,7,1),(3,7,4,1),(3,8,3,1),(3,9,2,1),(3,10,1,1),(2,11,6,1),(4,12,2,1),(4,13,1,1),(5,1,7,1),(5,2,4,2),(5,4,5,2),(5,5,9,1),(5,6,8,1),(5,7,3,2),(5,8,2,2),(5,10,1,3),(5,11,6,1),(6,12,2,1),(6,13,1,1),(7,1,8,1),(7,2,5,2),(7,4,6,1),(7,5,7,1),(7,7,4,2),(7,8,3,2),(7,9,2,2),(7,10,1,3),(8,12,2,1),(8,13,1,1),(9,1,8,1),(9,2,4,2),(9,4,5,2),(9,5,7,1),(9,6,6,1),(9,7,3,2),(9,8,2,2),(9,10,1,3),(9,11,6,1),(10,12,2,1),(10,13,1,1),(11,1,8,1),(11,2,5,2),(11,4,6,1),(11,5,7,1),(11,7,4,2),(11,8,3,2),(11,9,2,2),(11,10,1,3),(12,12,2,1),(12,13,1,1),(13,15,1,1),(14,1,9,1),(14,2,4,2),(14,4,5,2),(14,5,8,1),(14,6,7,1),(14,7,3,2),(14,8,2,2),(14,10,1,3),(14,11,6,1),(15,12,2,1),(15,13,1,1),(16,1,8,1),(16,2,5,2),(16,4,6,1),(16,5,7,1),(16,7,4,2),(16,8,3,2),(16,9,2,2),(16,10,1,3),(17,15,1,1),(18,12,2,1),(18,13,1,1),(19,1,9,1),(19,2,4,2),(19,4,5,2),(19,5,8,1),(19,6,7,1),(19,7,3,2),(19,8,2,2),(19,10,1,3),(19,11,6,1),(20,15,1,1),(21,16,1,1),(22,16,1,1),(23,12,2,1),(23,13,1,1),(24,1,8,1),(24,2,5,2),(24,4,6,1),(24,5,7,1),(24,7,4,2),(24,8,3,2),(24,9,2,2),(24,10,1,3),(25,15,1,1),(26,12,2,1),(26,13,1,1),(28,15,1,1),(30,16,1,1),(29,12,2,1),(29,13,1,1),(27,1,9,1),(27,2,4,2),(27,4,5,2),(27,5,8,1),(27,6,7,1),(27,7,3,2),(27,8,2,2),(27,10,1,3),(27,11,6,1),(31,1,8,1),(31,2,5,2),(31,4,6,1),(31,5,7,1),(31,7,4,2),(31,8,3,2),(31,9,2,2),(31,10,1,3),(32,12,2,1),(32,13,1,1);
/*!40000 ALTER TABLE `payroll_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:07
