-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees_earnings`
--

DROP TABLE IF EXISTS `employees_earnings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_earnings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `company_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `earning_id` int(20) NOT NULL,
  `amount` decimal(30,5) NOT NULL,
  `max_amount` decimal(30,5) DEFAULT '0.00000',
  `start_date` date DEFAULT NULL,
  `computed` varchar(10) DEFAULT NULL,
  `active` int(1) DEFAULT '0',
  `trash` int(1) DEFAULT '0',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `name_id` (`name_id`,`earning_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_earnings`
--

LOCK TABLES `employees_earnings` WRITE;
/*!40000 ALTER TABLE `employees_earnings` DISABLE KEYS */;
INSERT INTO `employees_earnings` VALUES (1,1,30,1,2000.00000,0.00000,'2017-02-01','month',1,0,NULL),(2,1,26,1,8342.22000,0.00000,'2017-02-01','month',1,0,NULL),(3,1,27,1,8342.22000,0.00000,'2017-02-01','month',1,0,NULL),(4,1,28,1,8342.22000,0.00000,'2017-02-01','month',1,0,NULL),(5,1,29,1,8342.22000,0.00000,'2017-02-01','month',1,0,NULL),(6,1,44,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(7,1,34,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(8,1,45,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(9,1,40,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(10,1,33,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(11,1,47,2,1500.00000,0.00000,'2017-02-01','month',1,0,NULL),(12,1,36,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(13,1,43,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(14,1,35,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(15,1,32,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(16,1,41,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(17,1,46,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(18,1,39,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(19,1,42,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(20,1,37,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(21,1,38,2,750.00000,0.00000,'2017-02-01','month',1,0,NULL),(22,2,52,1,6000.00000,0.00000,'2017-03-01','month',1,0,NULL),(23,2,53,1,4000.00000,0.00000,'2017-03-01','month',1,0,NULL),(24,1,55,2,750.00000,0.00000,'2017-06-09','month',1,0,NULL),(25,1,56,2,750.00000,0.00000,'2017-06-09','month',1,0,NULL),(26,4,57,1,8888.55000,0.00000,'2017-06-27','month',1,0,NULL),(27,4,58,1,8888.55000,0.00000,'2017-06-27','month',1,0,NULL),(28,1,60,2,750.00000,0.00000,'2017-07-11','month',1,0,NULL),(29,1,59,2,750.00000,0.00000,'2017-07-26','month',1,0,NULL),(30,2,61,1,3000.00000,0.00000,'2017-07-28','month',1,0,NULL);
/*!40000 ALTER TABLE `employees_earnings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:04
