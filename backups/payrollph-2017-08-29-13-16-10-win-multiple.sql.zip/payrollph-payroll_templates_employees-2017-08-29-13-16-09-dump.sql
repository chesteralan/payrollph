-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: payrollph
-- ------------------------------------------------------
-- Server version	5.5.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `payroll_templates_employees`
--

DROP TABLE IF EXISTS `payroll_templates_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_templates_employees` (
  `template_id` int(20) NOT NULL,
  `name_id` int(20) NOT NULL,
  `order` int(2) NOT NULL DEFAULT '0',
  `template` varchar(20) DEFAULT 'payslip',
  `print_group` int(20) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  KEY `name_id` (`template_id`,`name_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_templates_employees`
--

LOCK TABLES `payroll_templates_employees` WRITE;
/*!40000 ALTER TABLE `payroll_templates_employees` DISABLE KEYS */;
INSERT INTO `payroll_templates_employees` VALUES (2,1,1,'payslip',1,1),(2,2,4,'payslip',1,1),(2,12,5,'payslip',1,1),(2,5,7,'payslip',1,1),(2,8,8,'payslip',1,1),(2,25,0,'payslip',2,1),(2,20,2,'payslip',2,1),(2,22,3,'payslip',2,1),(2,23,6,'payslip',2,1),(2,44,12,'payslip',3,1),(2,34,2,'payslip',3,1),(2,40,8,'payslip',3,1),(2,47,15,'payslip',3,1),(2,35,3,'payslip',3,1),(2,32,0,'payslip',3,1),(2,41,9,'payslip',3,1),(2,46,14,'payslip',3,1),(2,39,7,'payslip',3,1),(2,42,10,'payslip',3,1),(2,37,5,'payslip',3,1),(2,43,11,'payslip',3,1),(2,36,4,'payslip',3,1),(2,26,0,'payslip',9,1),(2,29,3,'payslip',8,1),(2,15,1,'payslip',1,1),(2,14,0,'payslip',1,1),(2,16,2,'payslip',1,1),(2,17,3,'payslip',1,1),(2,18,4,'payslip',2,1),(2,7,0,'payslip',1,1),(2,11,1,'payslip',1,1),(2,3,0,'payslip',1,1),(2,4,1,'payslip',1,1),(2,6,2,'payslip',1,1),(2,13,4,'payslip',1,1),(2,24,5,'payslip',1,1),(2,28,2,'payslip',8,1),(2,10,0,'payslip',1,1),(2,21,1,'payslip',2,1),(2,19,0,'payslip',2,1),(1,1,1,'payslip',1,1),(1,2,4,'payslip',1,1),(1,12,5,'payslip',1,1),(1,5,7,'payslip',1,1),(1,8,8,'payslip',1,1),(1,25,0,'payslip',2,1),(1,20,2,'payslip',2,1),(1,22,3,'payslip',2,1),(1,23,6,'payslip',2,1),(1,44,2,'payslip',3,1),(1,34,4,'payslip',3,1),(1,40,6,'payslip',3,1),(1,47,7,'payslip',3,1),(1,35,9,'payslip',3,1),(1,32,10,'payslip',3,1),(1,41,11,'payslip',3,1),(1,46,12,'payslip',3,1),(1,39,13,'payslip',3,1),(1,42,14,'payslip',3,1),(1,37,15,'payslip',3,1),(1,43,17,'payslip',3,1),(1,36,19,'payslip',3,1),(1,26,9,'payslip',2,0),(1,29,10,'payslip',2,0),(1,3,0,'payslip',1,1),(1,4,1,'payslip',1,1),(1,6,2,'payslip',1,1),(1,13,4,'payslip',1,1),(1,24,5,'payslip',1,1),(1,7,0,'payslip',1,1),(1,11,1,'payslip',1,1),(1,10,1,'payslip',1,1),(1,21,0,'payslip',2,1),(1,15,2,'payslip',1,1),(1,14,1,'payslip',1,1),(1,16,3,'payslip',1,1),(1,17,4,'payslip',1,1),(1,18,0,'payslip',2,1),(1,19,0,'payslip',2,1),(1,30,0,'payslip',2,1),(1,28,0,'payslip',2,0),(2,30,0,'cash_voucher',2,1),(2,27,1,'payslip',8,1),(1,27,0,'payslip',0,0),(3,48,0,'payslip',NULL,1),(3,49,0,'payslip',NULL,1),(3,50,0,'payslip',NULL,1),(3,51,0,'payslip',NULL,1),(3,52,1,'payslip',0,1),(3,53,2,'payslip',0,1),(4,48,1,'payslip',0,1),(4,49,0,'payslip',0,1),(4,50,3,'payslip',0,1),(4,51,2,'payslip',0,1),(4,52,0,'payslip',0,1),(4,53,1,'payslip',0,1),(5,54,0,'payslip',0,1),(6,54,0,'payslip',0,1),(1,55,0,'payslip',3,1),(2,55,16,'payslip',3,1),(7,57,0,'payslip',NULL,1),(7,58,0,'payslip',NULL,1),(8,57,0,'payslip',NULL,1),(8,58,0,'payslip',NULL,1),(2,56,17,'payslip',3,1),(2,59,18,'payslip',3,1),(1,56,8,'payslip',3,1),(1,59,18,'payslip',3,1),(1,60,1,'payslip',3,1),(2,60,19,'payslip',3,1),(3,61,0,'payslip',0,1),(4,61,2,'payslip',0,1);
/*!40000 ALTER TABLE `payroll_templates_employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-29 19:16:09
