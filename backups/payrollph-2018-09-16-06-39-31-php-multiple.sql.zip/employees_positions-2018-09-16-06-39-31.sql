INSERT INTO employees_positions (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("1","1","Cook",NULL,"0");
INSERT INTO employees_positions (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("2","1","Finance",NULL,"0");
INSERT INTO employees_positions (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("3","1","Admin",NULL,"0");

