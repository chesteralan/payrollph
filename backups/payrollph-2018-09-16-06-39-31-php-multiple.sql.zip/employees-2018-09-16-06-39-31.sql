INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("1","1","4","2","1",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("13","1","5","0","1","2018-09-10",NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("12","1","5","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("7","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("8","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("10","1","5","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("11","1","5","0","0","2018-09-10","2",NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("4","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("5","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("2","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("3","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("6","1","4","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("9","1","5","0","0",NULL,NULL,NULL,"0",NULL);
INSERT INTO employees (`name_id`,`company_id`,`group_id`,`position_id`,`area_id`,`hired`,`status`,`notes`,`trash`,`employee_id`)  VALUES("14","1","4","0","0",NULL,NULL,NULL,"0",NULL);

