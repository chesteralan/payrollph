INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`order`,`page`)  VALUES("1","4","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`order`,`page`)  VALUES("1","5","1","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`order`,`page`)  VALUES("2","4","2","1");
INSERT INTO payroll_templates_groups (`template_id`,`group_id`,`order`,`page`)  VALUES("2","5","1","1");

