INSERT INTO companies_list (`id`,`theme`,`name`,`address`,`phone`,`notes`,`default`,`trash`)  VALUES("1","united","The Roman Catholic Bishop of Davao, Inc.","247 F. Torres St., Brgy 11-B Poblacion, Davao City","227-5992 / 221-1234 / 227-1163",NULL,"1","0");
INSERT INTO companies_list (`id`,`theme`,`name`,`address`,`phone`,`notes`,`default`,`trash`)  VALUES("2","yeti","Archdiocese of Davao Stewardship Apostolates, Inc.","247 F. Torres St., Brgy 11-B Poblacion, Davao City","227-5992 / 221-1234 / 227-1163",NULL,"0","0");
INSERT INTO companies_list (`id`,`theme`,`name`,`address`,`phone`,`notes`,`default`,`trash`)  VALUES("3","united","Catholic Campus Ministry of Davao","F. Torres St, Davao City",NULL,NULL,"0","0");
INSERT INTO companies_list (`id`,`theme`,`name`,`address`,`phone`,`notes`,`default`,`trash`)  VALUES("4","superhero","John XXIII Cathechetical Center","Holy Cross of Davao College, Inc",NULL,NULL,"0","0");
INSERT INTO companies_list (`id`,`theme`,`name`,`address`,`phone`,`notes`,`default`,`trash`)  VALUES("5","cerulean","Davao Clergy","247 F. Torres St, Davao City","227-5992 / 221-1234 / 227-1163",NULL,"0","0");

