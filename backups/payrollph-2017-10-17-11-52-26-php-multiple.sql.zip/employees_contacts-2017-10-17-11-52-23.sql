INSERT INTO employees_contacts (`name_id`,`phone_number`,`cell_number`,`address`)  VALUES("13","082-293-0261 / 082-298-0446","09462559955","Blk 55 Lot 7 Ph 2 Christ the King St\nBrgy. Sto. Nino, Tugbok");
INSERT INTO employees_contacts (`name_id`,`phone_number`,`cell_number`,`address`)  VALUES("20",NULL,"09082352248","247 F. Torres St., Davao City");
INSERT INTO employees_contacts (`name_id`,`phone_number`,`cell_number`,`address`)  VALUES("48",NULL,"SMART: 09300666481 Globe: 09169350712","Sikitan, Kidapawan City, North Cotabato");
INSERT INTO employees_contacts (`name_id`,`phone_number`,`cell_number`,`address`)  VALUES("51",NULL,"09307715072","Purok 5, Rambutan St., Tugbok, Davao City");
INSERT INTO employees_contacts (`name_id`,`phone_number`,`cell_number`,`address`)  VALUES("53",NULL,"09082580016","Sitio Mahayahay, Purok 11, Tugbok, Davao City");
INSERT INTO employees_contacts (`name_id`,`phone_number`,`cell_number`,`address`)  VALUES("61",NULL,"09124962260","Brgy. 8-A, Purok 9-B, Lower Madapo Hills, Davao City");

