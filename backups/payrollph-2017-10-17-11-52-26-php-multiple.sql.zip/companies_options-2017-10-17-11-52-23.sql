INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("5","column_group_earnings","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("5","column_group_deductions","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("5","column_group_sort","a:6:{i:0;s:21:\"column_group_earnings\";i:1;s:23:\"column_group_deductions\";i:2;s:20:\"column_group_summary\";i:3;s:21:\"column_group_salaries\";i:4;s:16:\"column_group_dtr\";i:5;s:21:\"column_group_benefits\";}");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("5","column_group_summary","s:1:\"1\";");
INSERT INTO companies_options (`company_id`,`key`,`value`)  VALUES("2","print_css","s:4:\"asdf\";");

