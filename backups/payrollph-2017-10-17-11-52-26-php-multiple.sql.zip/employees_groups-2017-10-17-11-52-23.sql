INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("1","1","Domestic / Household",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("2","1","Diocese Farms",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("3","1","Honorarium-based",NULL,"1");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("4","1","Pastoral Office",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("5","1","Oeconomus / Finance",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("6","1","Support Staff (Nuns)",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("7","1","Oeconomus / Nazareth",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("8","1","Oeconomus / Cemetery",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("9","1","Retainers Fee",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("10","1","Working Scholars",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("11","1","Matrimonal Tribunal",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("12","2","Regular Employees",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("13","2","Honorarium-based",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("14","1","Probationary",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("15","3","Regular",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("16","4","JCC",NULL,"0");
INSERT INTO employees_groups (`id`,`company_id`,`name`,`notes`,`trash`)  VALUES("17","5","Davao Clergy",NULL,"0");

