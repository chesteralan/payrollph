INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("1","Regular",NULL,"print_group","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("2","Honorarium Based",NULL,"print_group","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("3","Working Scholars",NULL,"print_group","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("4","Regular Employees",NULL,"employment_status","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("5","Probationary",NULL,"employment_status","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("6","Working Students",NULL,"employment_status","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("7","Non-Regular Employees",NULL,"employment_status","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("8","TDM",NULL,"print_group","0","0");
INSERT INTO terms_list (`id`,`name`,`notes`,`type`,`trash`,`priority`)  VALUES("9","Dominican",NULL,"print_group","0","0");

