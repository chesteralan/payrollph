INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("1","SSS Loan","SSS Loan",NULL,"1","0");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("2","HDMF Loan","HDMF Loan",NULL,"1","0");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("3","WTax","Withholding Tax",NULL,"1","0");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("4","CA","Cash Advance",NULL,"1","0");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("5","SLoan","Salary Loan",NULL,"1","0");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("6","Rice","Rice Loan",NULL,"1","0");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("7","DLPC","Light Bill",NULL,"1","0");
INSERT INTO deductions_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("8","Adjustments","Adjustments",NULL,"1","0");

