INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("1","alchie","941533a479a78dd89e3dacb0b38641809ed5bfcd","Alchie Tagudin");
INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("3","fred","a94a8fe5ccb19ba61c4c0873d391e987982fbbd3","Siegfred Alegro");

