INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("6","2018-01-31","8","0",NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("14","2018-01-31","8","0",NULL);
INSERT INTO employees_absences (`name_id`,`date_absent`,`hours`,`leave_type`,`notes`)  VALUES("1","2018-09-01","8","0",NULL);

