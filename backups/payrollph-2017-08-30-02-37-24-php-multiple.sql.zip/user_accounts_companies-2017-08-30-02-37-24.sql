INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("1","1");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("1","2");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("1","3");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("1","4");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("2","1");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("2","2");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("3","3");
INSERT INTO user_accounts_companies (`uid`,`company_id`)  VALUES("3","4");

