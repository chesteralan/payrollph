INSERT INTO user_accounts_options (`uid`,`department`,`section`,`key`,`value`)  VALUES("1","my","settings","theme","united");
INSERT INTO user_accounts_options (`uid`,`department`,`section`,`key`,`value`)  VALUES("2","my","settings","theme","united");

