INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("1","alchie","941533a479a78dd89e3dacb0b38641809ed5bfcd","Alchie Tagudin");
INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("2","jess","7110eda4d09e062aa5e4a390b0a572ac0d2c0220","Ariane Jess Loremas");
INSERT INTO user_accounts (`id`,`username`,`password`,`name`)  VALUES("3","fred","87288a5b100dc110adb07d9143cdaa7cf5b6c035","Siegfred Alegro");

