INSERT INTO earnings_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("1","Honorarium","Honorarium",NULL,"1","0");
INSERT INTO earnings_list (`id`,`name`,`notes`,`account_title`,`active`,`trash`)  VALUES("2","Allowance","Allowance",NULL,"1","0");

