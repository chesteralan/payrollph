INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("1","2","1");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("2","1","2");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("2","3","1");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("3","2","1");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("4","1","2");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("4","3","1");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("5","1","3");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("5","2","2");
INSERT INTO payroll_templates_benefits (`template_id`,`benefit_id`,`order`)  VALUES("5","3","1");

