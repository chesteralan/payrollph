INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`active`)  VALUES("1","1","15th Payroll - RCBDI","3","13","31","1");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`active`)  VALUES("2","1","30th Payroll - RCBDI","3","9","31","1");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`active`)  VALUES("3","2","15th Payroll","1","24","31","1");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`active`)  VALUES("4","2","30th Payroll","1","24","31","1");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`active`)  VALUES("5","3","15th payroll","1","13","31","1");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`active`)  VALUES("6","3","30th Payroll","1","13","31","1");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`active`)  VALUES("7","4","30th payroll","1","0","0","0");
INSERT INTO payroll_templates (`id`,`company_id`,`name`,`pages`,`checked_by`,`approved_by`,`active`)  VALUES("8","4","30th payroll","1","0","0","1");

